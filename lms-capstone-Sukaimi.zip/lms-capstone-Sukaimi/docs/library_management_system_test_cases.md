# Library Management System - Test Cases

## 1. Introduction

This document outlines the test cases for the Library Management System. It covers the functional testing of all major system components including user authentication, book management, search functionality, and borrowing operations.

## 2. Test Environment

### 2.1 Hardware Requirements
- Any modern computer capable of running the required software

### 2.2 Software Requirements
- Backend: Java 17+, Spring Boot 3.x
- Frontend: Node.js 18+, React 19.x
- Database: MySQL 8.x
- Browser: Chrome (latest), Firefox (latest), Safari (latest), Edge (latest)

### 2.3 Test Data Requirements
- Sample user accounts (librarian and member roles)
- Sample book records with various statuses
- Sample borrowing records

## 3. User Authentication Test Cases

### 3.1 User Registration

| Test ID | TC-UR-001 |
|---------|-----------|
| Test Case Description | Verify that a new user can register with valid information |
| Preconditions | 1. Application is running<br>2. User is on the registration page<br>3. User does not already exist in the system |
| Test Steps | 1. Enter name: "John Doe"<br>2. Enter email: "john.doe@example.com"<br>3. Enter password: "Password123!"<br>4. Click on "Register" button |
| Expected Result | 1. User is successfully registered<br>2. Success message is displayed<br>3. User is redirected to login page<br>4. User is assigned MEMBER role by default |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-UR-002 |
|---------|-----------|
| Test Case Description | Verify that registration fails with duplicate email |
| Preconditions | 1. Application is running<br>2. User is on registration page<br>3. User with email "existing@example.com" already exists |
| Test Steps | 1. Enter name: "Jane Smith"<br>2. Enter email: "existing@example.com"<br>3. Enter password: "Password456!"<br>4. Click on "Register" button |
| Expected Result | 1. Registration fails<br>2. Error message "Email already exists" is displayed<br>3. User remains on registration page |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-UR-003 |
|---------|-----------|
| Test Case Description | Verify password complexity validation |
| Preconditions | 1. Application is running<br>2. User is on registration page |
| Test Steps | 1. Enter name: "Alex Brown"<br>2. Enter email: "alex@example.com"<br>3. Enter password: "weak"<br>4. Click on "Register" button |
| Expected Result | 1. Registration fails<br>2. Error message about password complexity is displayed<br>3. User remains on registration page |
| Actual Result | |
| Status | Not Executed |

### 3.2 User Login

| Test ID | TC-UL-001 |
|---------|-----------|
| Test Case Description | Verify user can login with valid credentials |
| Preconditions | 1. Application is running<br>2. User is on login page<br>3. User "john.doe@example.com" exists with password "Password123!" |
| Test Steps | 1. Enter email: "john.doe@example.com"<br>2. Enter password: "Password123!"<br>3. Click on "Login" button |
| Expected Result | 1. Login is successful<br>2. User is redirected to home/dashboard page<br>3. User's name is displayed in the header |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-UL-002 |
|---------|-----------|
| Test Case Description | Verify login fails with invalid credentials |
| Preconditions | 1. Application is running<br>2. User is on login page |
| Test Steps | 1. Enter email: "john.doe@example.com"<br>2. Enter password: "WrongPassword"<br>3. Click on "Login" button |
| Expected Result | 1. Login fails<br>2. Error message "Invalid credentials" is displayed<br>3. User remains on login page |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-UL-003 |
|---------|-----------|
| Test Case Description | Verify user can logout |
| Preconditions | 1. Application is running<br>2. User is logged in |
| Test Steps | 1. Click on "Logout" button/link |
| Expected Result | 1. User is logged out<br>2. User is redirected to login page<br>3. User cannot access protected pages without logging in again |
| Actual Result | |
| Status | Not Executed |

## 4. Book Management Test Cases

### 4.1 Add Book

| Test ID | TC-BA-001 |
|---------|-----------|
| Test Case Description | Verify librarian can add a new book |
| Preconditions | 1. Application is running<br>2. Librarian is logged in<br>3. Librarian is on the add book page |
| Test Steps | 1. Enter title: "Test Book Title"<br>2. Enter author: "Test Author"<br>3. Enter ISBN: "9781234567897"<br>4. Enter publication year: "2023"<br>5. Enter category: "Fiction"<br>6. Enter description: "Test book description"<br>7. Click "Add Book" button |
| Expected Result | 1. Book is added successfully<br>2. Success message is displayed<br>3. Book appears in the book list<br>4. Book status is set to AVAILABLE by default |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BA-002 |
|---------|-----------|
| Test Case Description | Verify validation for duplicate ISBN |
| Preconditions | 1. Application is running<br>2. Librarian is logged in<br>3. Book with ISBN "9781234567897" already exists<br>4. Librarian is on the add book page |
| Test Steps | 1. Enter title: "Another Book"<br>2. Enter author: "Another Author"<br>3. Enter ISBN: "9781234567897"<br>4. Enter publication year: "2022"<br>5. Enter category: "Non-fiction"<br>6. Enter description: "Another book description"<br>7. Click "Add Book" button |
| Expected Result | 1. Book addition fails<br>2. Error message "ISBN already exists" is displayed<br>3. User remains on add book page |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BA-003 |
|---------|-----------|
| Test Case Description | Verify only librarians can access add book functionality |
| Preconditions | 1. Application is running<br>2. Member is logged in |
| Test Steps | 1. Attempt to navigate to add book page |
| Expected Result | 1. Access is denied<br>2. User is redirected to an appropriate page or shown an error message |
| Actual Result | |
| Status | Not Executed |

### 4.2 Edit Book

| Test ID | TC-BE-001 |
|---------|-----------|
| Test Case Description | Verify librarian can edit a book |
| Preconditions | 1. Application is running<br>2. Librarian is logged in<br>3. Book with ID exists in the system<br>4. Librarian is on the book detail/edit page |
| Test Steps | 1. Modify title to: "Updated Book Title"<br>2. Modify author to: "Updated Author"<br>3. Click "Save" button |
| Expected Result | 1. Book is updated successfully<br>2. Success message is displayed<br>3. Updated information is reflected in the book list and details |
| Actual Result | |
| Status | Not Executed |

### 4.3 Delete Book

| Test ID | TC-BD-001 |
|---------|-----------|
| Test Case Description | Verify librarian can delete a book |
| Preconditions | 1. Application is running<br>2. Librarian is logged in<br>3. Book with ID exists in the system<br>4. Librarian is on the book list page |
| Test Steps | 1. Locate the book to be deleted<br>2. Click "Delete" button<br>3. Confirm deletion in the confirmation dialog |
| Expected Result | 1. Book is deleted successfully<br>2. Success message is displayed<br>3. Book no longer appears in the book list |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BD-002 |
|---------|-----------|
| Test Case Description | Verify borrowed books cannot be deleted |
| Preconditions | 1. Application is running<br>2. Librarian is logged in<br>3. Book with ID exists in the system with status BORROWED<br>4. Librarian is on the book list page |
| Test Steps | 1. Locate the borrowed book<br>2. Click "Delete" button |
| Expected Result | 1. Delete operation fails<br>2. Error message "Cannot delete borrowed book" is displayed<br>3. Book remains in the list |
| Actual Result | |
| Status | Not Executed |

## 5. Book Search Test Cases

| Test ID | TC-BS-001 |
|---------|-----------|
| Test Case Description | Verify search by title functionality |
| Preconditions | 1. Application is running<br>2. User is logged in<br>3. Books with various titles exist in the system<br>4. User is on the search page or main page with search bar |
| Test Steps | 1. Enter search term: "Programming"<br>2. Click "Search" button |
| Expected Result | 1. Search results are displayed<br>2. Only books with "Programming" in their title are shown<br>3. Book details and status are correctly displayed |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BS-002 |
|---------|-----------|
| Test Case Description | Verify partial matching and case insensitivity in search |
| Preconditions | 1. Application is running<br>2. User is logged in<br>3. Book with title "Advanced Programming in Python" exists<br>4. User is on the search page |
| Test Steps | 1. Enter search term: "prog"<br>2. Click "Search" button |
| Expected Result | 1. The book "Advanced Programming in Python" is included in search results<br>2. Other books with "prog" in their title are also displayed |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BS-003 |
|---------|-----------|
| Test Case Description | Verify search with no results |
| Preconditions | 1. Application is running<br>2. User is logged in<br>3. No books with "NonExistentTitle" exist<br>4. User is on the search page |
| Test Steps | 1. Enter search term: "NonExistentTitle"<br>2. Click "Search" button |
| Expected Result | 1. No results are displayed<br>2. Appropriate message "No books found matching your search criteria" is shown |
| Actual Result | |
| Status | Not Executed |

## 6. Book Borrowing Test Cases

### 6.1 Borrow Book

| Test ID | TC-BB-001 |
|---------|-----------|
| Test Case Description | Verify member can borrow an available book |
| Preconditions | 1. Application is running<br>2. Member is logged in<br>3. Book with status AVAILABLE exists<br>4. Member is on the book list or search results page |
| Test Steps | 1. Locate the available book<br>2. Click "Borrow" button<br>3. Confirm borrowing action if prompted |
| Expected Result | 1. Book is borrowed successfully<br>2. Success message is displayed<br>3. Book status changes to BORROWED<br>4. Borrowing record is created with current date |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BB-002 |
|---------|-----------|
| Test Case Description | Verify borrowed books cannot be borrowed again |
| Preconditions | 1. Application is running<br>2. Member is logged in<br>3. Book with status BORROWED exists<br>4. Member is on the book list or search results page |
| Test Steps | 1. Locate the borrowed book<br>2. Observe that the "Borrow" button is disabled or not present<br>3. Alternatively, if button is present, click "Borrow" button |
| Expected Result | 1. Either the "Borrow" button is disabled/not present OR<br>2. If clicked, borrow operation fails with message "Book is already borrowed" |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BB-003 |
|---------|-----------|
| Test Case Description | Verify borrowing limit enforcement |
| Preconditions | 1. Application is running<br>2. Member is logged in<br>3. Member has already borrowed maximum allowed books (5)<br>4. Available book exists<br>5. Member is on the book list page |
| Test Steps | 1. Locate an available book<br>2. Click "Borrow" button |
| Expected Result | 1. Borrow operation fails<br>2. Error message "You have reached the maximum borrowing limit" is displayed |
| Actual Result | |
| Status | Not Executed |

### 6.2 Return Book

| Test ID | TC-BR-001 |
|---------|-----------|
| Test Case Description | Verify librarian can process book return |
| Preconditions | 1. Application is running<br>2. Librarian is logged in<br>3. Book with status BORROWED exists<br>4. Librarian is on the book list page |
| Test Steps | 1. Locate the borrowed book<br>2. Click "Return" button<br>3. Confirm return action if prompted |
| Expected Result | 1. Book return is processed successfully<br>2. Success message is displayed<br>3. Book status changes to AVAILABLE<br>4. Borrowing record is updated with return date |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-BR-002 |
|---------|-----------|
| Test Case Description | Verify available books cannot be returned |
| Preconditions | 1. Application is running<br>2. Librarian is logged in<br>3. Book with status AVAILABLE exists<br>4. Librarian is on the book list page |
| Test Steps | 1. Locate the available book<br>2. Observe that the "Return" button is disabled or not present<br>3. Alternatively, if button is present, click "Return" button |
| Expected Result | 1. Either the "Return" button is disabled/not present OR<br>2. If clicked, return operation fails with message "Book is not borrowed" |
| Actual Result | |
| Status | Not Executed |

## 7. Role-Based Access Control Test Cases

| Test ID | TC-RBAC-001 |
|---------|-----------|
| Test Case Description | Verify LIBRARIAN role can access all features |
| Preconditions | 1. Application is running<br>2. User with LIBRARIAN role is logged in |
| Test Steps | 1. Navigate to book management features (add/edit/delete)<br>2. Navigate to book return functionality<br>3. Navigate to search functionality |
| Expected Result | 1. Librarian can access all features<br>2. All administrative functions are available<br>3. No access restrictions encountered |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-RBAC-002 |
|---------|-----------|
| Test Case Description | Verify MEMBER role has limited access |
| Preconditions | 1. Application is running<br>2. User with MEMBER role is logged in |
| Test Steps | 1. Attempt to access add/edit/delete book functionality<br>2. Attempt to access book return functionality<br>3. Navigate to search and borrow functionality |
| Expected Result | 1. Member cannot access add/edit/delete book functions<br>2. Member cannot access return functionality<br>3. Member can access search and borrow functionality |
| Actual Result | |
| Status | Not Executed |

| Test ID | TC-RBAC-003 |
|---------|-----------|
| Test Case Description | Verify unauthenticated users have minimal access |
| Preconditions | 1. Application is running<br>2. No user is logged in |
| Test Steps | 1. Attempt to access protected pages (book management, borrowing, etc.)<br>2. Attempt to view login and registration pages |
| Expected Result | 1. Unauthenticated user cannot access protected pages<br>2. User is redirected to login page<br>3. User can access login and registration pages |
| Actual Result | |
| Status | Not Executed |

## 8. Test Data

### 8.1 Sample Users

| Username | Email | Password | Role |
|----------|-------|----------|------|
| admin | admin@library.com | AdminPass123! | LIBRARIAN |
| john.doe | john.doe@example.com | Password123! | MEMBER |
| jane.smith | jane.smith@example.com | Password456! | MEMBER |

### 8.2 Sample Books

| Title | Author | ISBN | Publication Year | Category | Status |
|-------|--------|------|------------------|----------|--------|
| The Art of Programming | Jane Developer | 9781234567897 | 2020 | Programming | AVAILABLE |
| Database Design | John Smith | 9789876543210 | 2019 | Technology | AVAILABLE |
| Web Development Basics | Sarah Johnson | 9785432167890 | 2021 | Programming | BORROWED |
| Machine Learning 101 | Michael Lee | 9781357924680 | 2022 | Technology | AVAILABLE |
| Cloud Computing | Emma Wilson | 9782468013579 | 2023 | Technology | BORROWED |

## 9. Traceability Matrix

| Requirement ID | Test Case ID |
|----------------|--------------|
| FR-UA-1, FR-UA-2, FR-UA-6 | TC-UL-001, TC-UL-002 |
| FR-UA-5 | TC-UL-003 |
| FR-UR-1, FR-UR-4, FR-UR-6 | TC-UR-001 |
| FR-UR-2 | TC-UR-002 |
| FR-UR-3, FR-UR-5 | TC-UR-003 |
| FR-BM-1, FR-BM-4 | TC-BA-001 |
| FR-BM-5 | TC-BA-002 |
| FR-RBAC-1, FR-RBAC-2 | TC-BA-003 |
| FR-BM-2 | TC-BE-001 |
| FR-BM-3 | TC-BD-001, TC-BD-002 |
| FR-BS-1, FR-BS-2, FR-BS-5 | TC-BS-001 |
| FR-BS-6 | TC-BS-002 |
| FR-BS-7 | TC-BS-003 |
| FR-BB-1, FR-BB-3, FR-BB-4, FR-BB-6 | TC-BB-001 |
| FR-BB-2 | TC-BB-002 |
| FR-BB-5 | TC-BB-003 |
| FR-BR-1, FR-BR-2, FR-BR-3, FR-BR-4, FR-BR-5 | TC-BR-001, TC-BR-002 |
| FR-RBAC-1, FR-RBAC-2, FR-RBAC-3, FR-RBAC-5 | TC-RBAC-001 |
| FR-RBAC-3, FR-RBAC-4 | TC-RBAC-002 |
| All security requirements | TC-RBAC-003 | 