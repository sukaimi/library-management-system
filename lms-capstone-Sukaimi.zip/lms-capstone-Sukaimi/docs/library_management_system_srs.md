# Library Management System - Software Requirements Specification

## 1. Introduction

### 1.1 Purpose
This Software Requirements Specification (SRS) document provides a detailed description of the functional and non-functional requirements for the Library Management System (LMS). It serves as a reference for the development team to implement the system according to specified requirements.

### 1.2 Document Conventions
- **SRS**: Software Requirements Specification
- **API**: Application Programming Interface
- **UI**: User Interface
- **CRUD**: Create, Read, Update, Delete

### 1.3 Intended Audience
This document is intended for:
- Development team
- Quality assurance team
- Project stakeholders
- System administrators

### 1.4 Product Scope
The Library Management System is a web-based application that manages library resources, user accounts, and book lending operations. It provides interfaces for both librarians and members to interact with library services.

### 1.5 References
- Business Requirements Document (BRD)
- IEEE 830-1998 SRS standards
- Spring Boot documentation
- React documentation

## 2. Overall Description

### 2.1 Product Perspective
The Library Management System is a standalone web application consisting of:
- React-based frontend
- Spring Boot REST API backend
- MySQL database

### 2.2 Product Features
- User authentication and authorization
- Book management (CRUD operations)
- Book search functionality
- Book borrowing and returning
- User role management

### 2.3 User Classes and Characteristics

#### 2.3.1 Librarian
- Tech-savvy staff with administrative privileges
- Responsible for book and user management
- Requires access to all system features
- Frequency of use: Daily, for several hours

#### 2.3.2 Member
- General library users with basic computer skills
- Primary interest in browsing and borrowing books
- Requires access to search and borrowing features
- Frequency of use: Occasional, typically for short sessions

### 2.4 Operating Environment
- **Server Environment**: Java 17+ runtime
- **Client Environment**: Modern web browsers (Chrome, Firefox, Safari, Edge)
- **Database**: MySQL 8.x
- **Network**: Standard HTTPS protocol

### 2.5 Design and Implementation Constraints
- Must use Spring Boot for backend implementation
- Must use React for frontend implementation
- Must use MySQL as the database
- Must implement responsive design for various screen sizes
- Must adhere to security best practices for authentication and data protection

### 2.6 User Documentation
The system will include:
- Online help documentation
- User manuals for librarians and members
- Technical documentation for system administrators

### 2.7 Assumptions and Dependencies
- Users have access to internet-connected devices
- Server hardware is capable of handling expected load
- Required software dependencies are available and compatible

## 3. System Features

### 3.1 User Authentication

#### 3.1.1 Description
The system shall provide secure authentication for users to access their accounts.

#### 3.1.2 Functional Requirements
| ID | Requirement |
|----|-------------|
| FR-UA-1 | The system shall provide a login page with email and password fields |
| FR-UA-2 | The system shall validate user credentials against stored data |
| FR-UA-3 | The system shall use JWT tokens for session management |
| FR-UA-4 | The system shall enforce password strength requirements |
| FR-UA-5 | The system shall provide logout functionality |
| FR-UA-6 | The system shall handle invalid login attempts with appropriate error messages |

### 3.2 User Registration

#### 3.2.1 Description
The system shall allow new users to create accounts with appropriate validation.

#### 3.2.2 Functional Requirements
| ID | Requirement |
|----|-------------|
| FR-UR-1 | The system shall provide a registration form with fields for name, email, and password |
| FR-UR-2 | The system shall validate that email addresses are unique |
| FR-UR-3 | The system shall enforce password complexity rules |
| FR-UR-4 | The system shall assign appropriate default role (MEMBER) to new registrations |
| FR-UR-5 | The system shall store passwords in encrypted form |
| FR-UR-6 | The system shall confirm successful registration with a notification |

### 3.3 Book Management

#### 3.3.1 Description
The system shall provide librarians with functionality to manage the book inventory.

#### 3.3.2 Functional Requirements
| ID | Requirement |
|----|-------------|
| FR-BM-1 | The system shall allow librarians to add new books with complete details |
| FR-BM-2 | The system shall allow librarians to edit existing book information |
| FR-BM-3 | The system shall allow librarians to delete books from the system |
| FR-BM-4 | The system shall validate book data (e.g., ISBN format, publication year) |
| FR-BM-5 | The system shall prevent duplicate ISBN entries |
| FR-BM-6 | The system shall maintain a log of all changes to book records |

### 3.4 Book Search

#### 3.4.1 Description
The system shall provide search functionality for users to find books by various criteria.

#### 3.4.2 Functional Requirements
| ID | Requirement |
|----|-------------|
| FR-BS-1 | The system shall provide a search interface with text input field |
| FR-BS-2 | The system shall allow searching by book title |
| FR-BS-3 | The system shall allow searching by author name |
| FR-BS-4 | The system shall allow searching by ISBN |
| FR-BS-5 | The system shall display search results with book details and availability status |
| FR-BS-6 | The system shall support partial matching and be case-insensitive |
| FR-BS-7 | The system shall provide appropriate messaging for no results found |

### 3.5 Book Borrowing

#### 3.5.1 Description
The system shall enable members to borrow available books and track their status.

#### 3.5.2 Functional Requirements
| ID | Requirement |
|----|-------------|
| FR-BB-1 | The system shall allow members to borrow available books |
| FR-BB-2 | The system shall prevent borrowing of already borrowed books |
| FR-BB-3 | The system shall update book status to "borrowed" upon successful borrowing |
| FR-BB-4 | The system shall record the borrowing transaction with date and user information |
| FR-BB-5 | The system shall limit the number of books a member can borrow simultaneously |
| FR-BB-6 | The system shall provide confirmation of successful borrowing |

### 3.6 Book Return

#### 3.6.1 Description
The system shall enable the return of borrowed books and update their status.

#### 3.6.2 Functional Requirements
| ID | Requirement |
|----|-------------|
| FR-BR-1 | The system shall allow librarians to process book returns |
| FR-BR-2 | The system shall update book status to "available" upon return |
| FR-BR-3 | The system shall record the return transaction with date |
| FR-BR-4 | The system shall provide confirmation of successful return |
| FR-BR-5 | The system shall update the borrowing record with the return date |

### 3.7 Role-Based Access Control

#### 3.7.1 Description
The system shall enforce appropriate access controls based on user roles.

#### 3.7.2 Functional Requirements
| ID | Requirement |
|----|-------------|
| FR-RBAC-1 | The system shall restrict administrative functions to the LIBRARIAN role |
| FR-RBAC-2 | The system shall restrict book management operations to the LIBRARIAN role |
| FR-RBAC-3 | The system shall allow both LIBRARIAN and MEMBER roles to search books |
| FR-RBAC-4 | The system shall allow only the MEMBER role to borrow books |
| FR-RBAC-5 | The system shall allow only the LIBRARIAN role to process returns |
| FR-RBAC-6 | The system shall hide or disable unauthorized functionality in the UI based on role |

## 4. External Interface Requirements

### 4.1 User Interfaces

#### 4.1.1 Login/Registration Interface
- Clean, responsive design with form validation
- Clear error messages for invalid inputs
- Links between login and registration pages

#### 4.1.2 Book Catalog Interface
- Responsive grid or list view of books
- Pagination for large result sets
- Sort and filter options
- Status indicators for each book

#### 4.1.3 Search Interface
- Prominent search bar
- Auto-suggestions (optional)
- Clear display of search results
- "No results" messaging when appropriate

#### 4.1.4 Book Management Interface (Librarian)
- Forms for adding and editing books
- Confirmation dialogs for delete operations
- Status updates for successful operations

#### 4.1.5 Borrowing/Return Interface
- Clear availability status
- Confirmation for borrow/return operations
- User feedback for successful/failed operations

### 4.2 Software Interfaces

#### 4.2.1 Frontend to Backend Interface
- RESTful API
- JSON data format
- HTTP status codes for error handling
- JWT authentication tokens in request headers

#### 4.2.2 Backend to Database Interface
- JPA/Hibernate ORM
- Connection pooling for efficiency
- Prepared statements for security

### 4.3 Communication Interfaces
- HTTPS protocol for all client-server communication
- Standard web ports (443 for HTTPS)
- JSON as the data interchange format

## 5. Non-Functional Requirements

### 5.1 Performance Requirements
- Page load time: < 2 seconds (95th percentile)
- Search response time: < 3 seconds (95th percentile)
- Book operation response time: < 2 seconds (95th percentile)
- System capable of handling 100+ concurrent users
- Database queries optimized for performance

### 5.2 Safety Requirements
- Data validation for all inputs
- Error handling to prevent system crashes
- Logging of system errors for troubleshooting
- Confirmation prompts for critical operations (delete, etc.)

### 5.3 Security Requirements
- Password encryption using bcrypt or similar algorithm
- JWT tokens with appropriate expiration
- HTTPS for all communications
- Protection against SQL injection
- Protection against XSS attacks
- CSRF protection
- Input validation on both client and server
- Rate limiting for authentication attempts

### 5.4 Software Quality Attributes

#### 5.4.1 Reliability
- System availability: 99.5% during operating hours
- Error rate: < 0.1% for all operations
- Data integrity checks for all transactions

#### 5.4.2 Availability
- Scheduled maintenance windows communicated to users
- Graceful degradation under high load

#### 5.4.3 Maintainability
- Modular code structure
- Comprehensive code documentation
- Consistent coding standards
- Test coverage > 80%

#### 5.4.4 Portability
- Cross-browser compatibility
- Responsive design for various devices
- Configuration settings for deployment environments

#### 5.4.5 Usability
- Intuitive navigation
- Consistent UI patterns
- Helpful error messages
- Tooltips for complex features
- Keyboard shortcuts for common operations

### 5.5 Business Rules

#### 5.5.1 Book Lending Rules
- Members can borrow up to 5 books simultaneously
- Borrowed books cannot be borrowed by other users
- Books must be returned within 14 days

#### 5.5.2 User Account Rules
- New accounts are assigned MEMBER role by default
- LIBRARIAN role can only be assigned by system administrators
- Inactive accounts will be locked after 180 days of inactivity

## 6. Other Requirements

### 6.1 Database Requirements
- Entity relationships properly defined
- Foreign key constraints enforced
- Indexes on frequently queried columns
- Transaction support for data integrity
- Backup and recovery procedures

### 6.2 Logging Requirements
- User authentication events
- Book management operations
- Borrowing and return transactions
- System errors and exceptions
- Performance metrics

### 6.3 Internationalization Requirements
- Support for multiple languages (future enhancement)
- Date and time formats adaptable to locale
- Support for UTF-8 encoding

## Appendix A: Data Models

### A.1 User Model
```
User {
    id: Long (Primary Key)
    name: String
    email: String (Unique)
    password: String (Encrypted)
    role: Enum [LIBRARIAN, MEMBER]
    status: Enum [ACTIVE, INACTIVE]
    registrationDate: Date
}
```

### A.2 Book Model
```
Book {
    id: Long (Primary Key)
    title: String
    author: String
    isbn: String (Unique)
    publicationYear: Integer
    category: String
    description: String
    availability: Enum [AVAILABLE, BORROWED]
}
```

### A.3 Borrowing Record Model
```
BorrowingRecord {
    id: Long (Primary Key)
    bookId: Long (Foreign Key)
    userId: Long (Foreign Key)
    borrowDate: Date
    returnDate: Date (Nullable)
    status: Enum [ACTIVE, COMPLETED]
}
```

## Appendix B: API Endpoints

### B.1 Authentication API
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Authenticate user
- `POST /api/auth/logout` - Logout user

### B.2 User API
- `GET /api/users` - Get all users (admin only)
- `GET /api/users/{id}` - Get user by ID
- `PUT /api/users/{id}` - Update user
- `DELETE /api/users/{id}` - Delete user (admin only)

### B.3 Book API
- `GET /api/books` - Get all books
- `GET /api/books/{id}` - Get book by ID
- `POST /api/books` - Add new book (admin only)
- `PUT /api/books/{id}` - Update book (admin only)
- `DELETE /api/books/{id}` - Delete book (admin only)
- `GET /api/books/search` - Search books by criteria

### B.4 Borrowing API
- `POST /api/books/{id}/borrow` - Borrow a book
- `PUT /api/books/{id}/return` - Return a book
- `GET /api/users/{id}/borrows` - Get user's borrowing history 