# Library Management System - Wireframes

## 1. Introduction

This document provides wireframes and UI specifications for the Library Management System. The wireframes illustrate the layout, components, and user flow of the application's key screens.

## 2. Common Elements

### 2.1 Header
```
+----------------------------------------------------------------------+
|  Logo                                         User Info   Logout      |
|                                                                      |
|  [Home] [Books] [Search] [+ Add Book (Librarian only)]               |
+----------------------------------------------------------------------+
```

- **Logo**: Library Management System logo displayed in the top-left corner
- **Navigation Menu**: Links to main sections of the application
- **User Info**: Shows currently logged-in user's name and role
- **Logout Button**: Positioned in the top-right corner

### 2.2 Footer
```
+----------------------------------------------------------------------+
|  © 2024 Library Management System                 Terms | Privacy     |
+----------------------------------------------------------------------+
```

- **Copyright**: Year and application name
- **Links**: Terms of service and privacy policy

## 3. Login/Registration Screens

### 3.1 Login Screen
```
+----------------------------------------------------------------------+
|                                                                      |
|                       LIBRARY MANAGEMENT SYSTEM                      |
|                                                                      |
|  +----------------------------------+                                |
|  |            LOGIN                 |                                |
|  |                                  |                                |
|  |  Email:                          |                                |
|  |  [                           ]   |                                |
|  |                                  |                                |
|  |  Password:                       |                                |
|  |  [                           ]   |                                |
|  |                                  |                                |
|  |  [        Login         ]        |                                |
|  |                                  |                                |
|  |  Don't have an account?          |                                |
|  |  [Register]                      |                                |
|  +----------------------------------+                                |
|                                                                      |
|  Demo Accounts:                                                      |
|  Librarian: librarian@example.com / password                         |
|  Member: member@example.com / password                               |
|                                                                      |
+----------------------------------------------------------------------+
```

- **Title**: Application name at the top
- **Login Form**: Centered on the page
- **Fields**:
  - Email input
  - Password input (masked)
- **Buttons**:
  - Login (primary action)
  - Register link to registration page
- **Demo Account Info**: For testing purposes

### 3.2 Registration Screen
```
+----------------------------------------------------------------------+
|                                                                      |
|                       LIBRARY MANAGEMENT SYSTEM                      |
|                                                                      |
|  +----------------------------------+                                |
|  |          REGISTER                |                                |
|  |                                  |                                |
|  |  Name:                           |                                |
|  |  [                           ]   |                                |
|  |                                  |                                |
|  |  Email:                          |                                |
|  |  [                           ]   |                                |
|  |                                  |                                |
|  |  Password:                       |                                |
|  |  [                           ]   |                                |
|  |                                  |                                |
|  |  Confirm Password:               |                                |
|  |  [                           ]   |                                |
|  |                                  |                                |
|  |  [      Register        ]        |                                |
|  |                                  |                                |
|  |  Already have an account?        |                                |
|  |  [Login]                         |                                |
|  +----------------------------------+                                |
|                                                                      |
+----------------------------------------------------------------------+
```

- **Title**: Application name at the top
- **Registration Form**: Centered on the page
- **Fields**:
  - Name input
  - Email input
  - Password input (masked)
  - Confirm password input (masked)
- **Buttons**:
  - Register (primary action)
  - Login link to login page

## 4. Book Management Screens

### 4.1 Book List Screen
```
+----------------------------------------------------------------------+
|  Logo                             User: John Doe (LIBRARIAN) Logout   |
|                                                                      |
|  [Home] [Books] [Search] [+ Add Book]                                |
+----------------------------------------------------------------------+
|                                                                      |
|  BOOK CATALOG                                    [Search]            |
|                                                  [Filter ▼]          |
|  +----------------------------------------------------------------+  |
|  |  Title          | Author       | ISBN      | Category | Status |  |
|  |----------------|--------------|-----------|----------|--------|  |
|  |  The Art of... | Jane Dev...  | 97812...  | Program. | AVAIL. |  |
|  |  [View] [Edit] [Delete] [Borrow/Return]                        |  |
|  |----------------------------------------------------------------|  |
|  |  Database De.. | John Smith   | 97898...  | Techno.  | AVAIL. |  |
|  |  [View] [Edit] [Delete] [Borrow/Return]                        |  |
|  |----------------------------------------------------------------|  |
|  |  Web Develop.. | Sarah John.. | 97854...  | Program. | BORROW.|  |
|  |  [View] [Edit] [Delete] [Borrow/Return]                        |  |
|  |----------------------------------------------------------------|  |
|  |  Machine Lear. | Michael Lee  | 97813...  | Techno.  | AVAIL. |  |
|  |  [View] [Edit] [Delete] [Borrow/Return]                        |  |
|  |----------------------------------------------------------------|  |
|  |  Cloud Compu.. | Emma Wilson  | 97824...  | Techno.  | BORROW.|  |
|  |  [View] [Edit] [Delete] [Borrow/Return]                        |  |
|  +----------------------------------------------------------------+  |
|                                                                      |
|  Showing 1-5 of 5 books          [< 1 >]                            |
|                                                                      |
+----------------------------------------------------------------------+
|  © 2024 Library Management System                 Terms | Privacy     |
+----------------------------------------------------------------------+
```

- **Header**: Standard header with navigation
- **Title**: "BOOK CATALOG" 
- **Search and Filter**: Top-right of content area
- **Book Table**:
  - Columns: Title, Author, ISBN, Category, Status
  - Action buttons for each book
- **Pagination**: Bottom of the table

### 4.2 Add/Edit Book Screen
```
+----------------------------------------------------------------------+
|  Logo                             User: John Doe (LIBRARIAN) Logout   |
|                                                                      |
|  [Home] [Books] [Search] [+ Add Book]                                |
+----------------------------------------------------------------------+
|                                                                      |
|  ADD NEW BOOK                                                        |
|                                                                      |
|  +----------------------------------------------------------------+  |
|  |                                                                |  |
|  |  Title:                                                        |  |
|  |  [                                                        ]    |  |
|  |                                                                |  |
|  |  Author:                                                       |  |
|  |  [                                                        ]    |  |
|  |                                                                |  |
|  |  ISBN:                                                         |  |
|  |  [                                                        ]    |  |
|  |                                                                |  |
|  |  Publication Year:                                             |  |
|  |  [                ]                                            |  |
|  |                                                                |  |
|  |  Category:                                                     |  |
|  |  [                    ▼]                                       |  |
|  |                                                                |  |
|  |  Description:                                                  |  |
|  |  [                                                        ]    |  |
|  |  [                                                        ]    |  |
|  |  [                                                        ]    |  |
|  |                                                                |  |
|  |  [Save]                                     [Cancel]          |  |
|  |                                                                |  |
|  +----------------------------------------------------------------+  |
|                                                                      |
+----------------------------------------------------------------------+
|  © 2024 Library Management System                 Terms | Privacy     |
+----------------------------------------------------------------------+
```

- **Header**: Standard header with navigation
- **Title**: "ADD NEW BOOK" or "EDIT BOOK" depending on context
- **Form Fields**:
  - Title (text input)
  - Author (text input)
  - ISBN (text input with validation)
  - Publication Year (number input)
  - Category (dropdown)
  - Description (textarea)
- **Buttons**:
  - Save (primary action)
  - Cancel (returns to book list)

### 4.3 Book Detail Screen
```
+----------------------------------------------------------------------+
|  Logo                            User: John Doe (LIBRARIAN) Logout    |
|                                                                      |
|  [Home] [Books] [Search] [+ Add Book]                                |
+----------------------------------------------------------------------+
|                                                                      |
|  BOOK DETAILS                                     [← Back to List]   |
|                                                                      |
|  +----------------------------------------------------------------+  |
|  |                                                                |  |
|  |  Title: The Art of Programming                                 |  |
|  |                                                                |  |
|  |  Author: Jane Developer                                        |  |
|  |                                                                |  |
|  |  ISBN: 9781234567897                                           |  |
|  |                                                                |  |
|  |  Publication Year: 2020                                        |  |
|  |                                                                |  |
|  |  Category: Programming                                         |  |
|  |                                                                |  |
|  |  Status: AVAILABLE                                             |  |
|  |                                                                |  |
|  |  Description:                                                  |  |
|  |  A comprehensive guide to modern programming techniques and    |  |
|  |  best practices. Covers multiple programming languages and     |  |
|  |  paradigms with practical examples.                            |  |
|  |                                                                |  |
|  |  [Edit]  [Delete]  [Borrow/Return]                            |  |
|  |                                                                |  |
|  +----------------------------------------------------------------+  |
|                                                                      |
+----------------------------------------------------------------------+
|  © 2024 Library Management System                 Terms | Privacy     |
+----------------------------------------------------------------------+
```

- **Header**: Standard header with navigation
- **Title**: "BOOK DETAILS"
- **Back Button**: Returns to book list
- **Information Display**:
  - Book details shown in labeled fields
  - Status prominently displayed
- **Action Buttons**:
  - Edit (Librarian only)
  - Delete (Librarian only)
  - Borrow/Return (context-sensitive based on status)

## 5. Search Functionality

### 5.1 Search Screen
```
+----------------------------------------------------------------------+
|  Logo                             User: Jane Smith (MEMBER) Logout    |
|                                                                      |
|  [Home] [Books] [Search]                                             |
+----------------------------------------------------------------------+
|                                                                      |
|  SEARCH BOOKS                                                        |
|                                                                      |
|  +----------------------------------------------------------------+  |
|  |                                                                |  |
|  |  Search by:  [Title ▼]                                         |  |
|  |                                                                |  |
|  |  [                                                 ] [Search]  |  |
|  |                                                                |  |
|  +----------------------------------------------------------------+  |
|                                                                      |
|  SEARCH RESULTS (3)                                                  |
|                                                                      |
|  +----------------------------------------------------------------+  |
|  |                                                                |  |
|  |  The Art of Programming                                    ↓   |  |
|  |  --------------------------------------------------------      |  |
|  |  Author: Jane Developer                                        |  |
|  |  ISBN: 9781234567897                                           |  |
|  |  Category: Programming                                         |  |
|  |  Status: AVAILABLE                         [Borrow]            |  |
|  |                                                                |  |
|  +----------------------------------------------------------------+  |
|  |                                                                |  |
|  |  Advanced Programming in Python                            ↓   |  |
|  |  --------------------------------------------------------      |  |
|  |  Author: Peter Wright                                          |  |
|  |  ISBN: 9789876543217                                           |  |
|  |  Category: Programming                                         |  |
|  |  Status: AVAILABLE                         [Borrow]            |  |
|  |                                                                |  |
|  +----------------------------------------------------------------+  |
|  |                                                                |  |
|  |  Programming Fundamentals                                  ↓   |  |
|  |  --------------------------------------------------------      |  |
|  |  Author: Robert Johnson                                        |  |
|  |  ISBN: 9781122334455                                           |  |
|  |  Category: Programming                                         |  |
|  |  Status: BORROWED                         [Unavailable]        |  |
|  |                                                                |  |
|  +----------------------------------------------------------------+  |
|                                                                      |
+----------------------------------------------------------------------+
|  © 2024 Library Management System                 Terms | Privacy     |
+----------------------------------------------------------------------+
```

- **Header**: Standard header with navigation
- **Search Form**: 
  - Type selector dropdown (Title, Author, ISBN)
  - Search text input
  - Search button
- **Results Display**:
  - Collapsible cards showing book information
  - Status and action button (Borrow/Return) for each result
  - Empty state message if no results found

## 6. User Dashboard

### 6.1 Member Dashboard
```
+----------------------------------------------------------------------+
|  Logo                             User: Jane Smith (MEMBER) Logout    |
|                                                                      |
|  [Home] [Books] [Search]                                             |
+----------------------------------------------------------------------+
|                                                                      |
|  MEMBER DASHBOARD                                                    |
|                                                                      |
|  Welcome, Jane Smith!                                                |
|                                                                      |
|  +---------------------------------+  +---------------------------+  |
|  |  MY BORROWED BOOKS (2)         |  |  QUICK ACTIONS            |  |
|  |---------------------------------|  |---------------------------|  |
|  |                                 |  |                           |  |
|  |  Web Development Basics        |  |  [Search Books]           |  |
|  |  Borrowed: 03/15/2024          |  |                           |  |
|  |  Due: 03/29/2024               |  |  [View All Books]         |  |
|  |                                 |  |                           |  |
|  |  Cloud Computing               |  |  [Update Profile]         |  |
|  |  Borrowed: 03/10/2024          |  |                           |  |
|  |  Due: 03/24/2024               |  |                           |  |
|  |                                 |  |                           |  |
|  +---------------------------------+  +---------------------------+  |
|                                                                      |
|  +-----------------------------------------------------------------+ |
|  |  RECENT ACTIVITY                                                | |
|  |-----------------------------------------------------------------| |
|  |                                                                 | |
|  |  03/15/2024 - Borrowed "Web Development Basics"                 | |
|  |  03/10/2024 - Borrowed "Cloud Computing"                        | |
|  |  03/05/2024 - Returned "Database Design"                        | |
|  |  02/20/2024 - Borrowed "Database Design"                        | |
|  |                                                                 | |
|  +-----------------------------------------------------------------+ |
|                                                                      |
+----------------------------------------------------------------------+
|  © 2024 Library Management System                 Terms | Privacy     |
+----------------------------------------------------------------------+
```

- **Header**: Standard header with navigation
- **Welcome Message**: Personalized greeting
- **Borrowed Books Section**:
  - List of books currently borrowed
  - Borrow date and due date for each
- **Quick Actions**: Links to common actions
- **Recent Activity**: Timeline of borrowing/returning activity

### 6.2 Librarian Dashboard
```
+----------------------------------------------------------------------+
|  Logo                             User: John Doe (LIBRARIAN) Logout   |
|                                                                      |
|  [Home] [Books] [Search] [+ Add Book]                                |
+----------------------------------------------------------------------+
|                                                                      |
|  LIBRARIAN DASHBOARD                                                 |
|                                                                      |
|  Welcome, John Doe!                                                  |
|                                                                      |
|  +---------------------------------+  +---------------------------+  |
|  |  SYSTEM STATISTICS              |  |  QUICK ACTIONS            |  |
|  |---------------------------------|  |---------------------------|  |
|  |                                 |  |                           |  |
|  |  Total Books: 25                |  |  [Add New Book]           |  |
|  |  Available: 18                  |  |                           |  |
|  |  Borrowed: 7                    |  |  [Manage Books]           |  |
|  |                                 |  |                           |  |
|  |  Registered Users: 12           |  |  [Process Returns]        |  |
|  |  Librarians: 2                  |  |                           |  |
|  |  Members: 10                    |  |  [View Recent Activity]   |  |
|  |                                 |  |                           |  |
|  +---------------------------------+  +---------------------------+  |
|                                                                      |
|  +-----------------------------------------------------------------+ |
|  |  BOOKS DUE FOR RETURN                                           | |
|  |-----------------------------------------------------------------| |
|  |                                                                 | |
|  |  "Web Development Basics" - Due: 03/29/2024 (Jane Smith)        | |
|  |  "Cloud Computing" - Due: 03/24/2024 (Jane Smith)               | |
|  |  "Machine Learning 101" - Due: 03/22/2024 (David Brown)         | |
|  |                                                                 | |
|  +-----------------------------------------------------------------+ |
|                                                                      |
|  +-----------------------------------------------------------------+ |
|  |  RECENT SYSTEM ACTIVITY                                         | |
|  |-----------------------------------------------------------------| |
|  |                                                                 | |
|  |  03/15/2024 - Book borrowed: "Web Development Basics"           | |
|  |  03/12/2024 - New book added: "Artificial Intelligence Basics"  | |
|  |  03/10/2024 - Book borrowed: "Cloud Computing"                  | |
|  |  03/08/2024 - New user registered: David Brown                  | |
|  |  03/05/2024 - Book returned: "Database Design"                  | |
|  |                                                                 | |
|  +-----------------------------------------------------------------+ |
|                                                                      |
+----------------------------------------------------------------------+
|  © 2024 Library Management System                 Terms | Privacy     |
+----------------------------------------------------------------------+
```

- **Header**: Standard header with navigation
- **Welcome Message**: Personalized greeting
- **System Statistics**:
  - Book counts (total, available, borrowed)
  - User counts by role
- **Quick Actions**: Links to common administrative actions
- **Books Due for Return**: List of books approaching return date
- **Recent System Activity**: Timeline of system events

## 7. Delete Confirmation Dialog
```
+----------------------------------------------------------------------+
|                    CONFIRM DELETION                     [X]          |
|                                                                      |
|  Are you sure you want to delete the following book?                 |
|                                                                      |
|  Title: Database Design                                              |
|  Author: John Smith                                                  |
|                                                                      |
|  This action cannot be undone.                                       |
|                                                                      |
|            [Cancel]                   [Delete]                        |
|                                                                      |
+----------------------------------------------------------------------+
```

- **Title**: "CONFIRM DELETION"
- **Close Button**: In top-right corner
- **Message**: Warning about deletion with item details
- **Buttons**:
  - Cancel (returns to previous screen)
  - Delete (confirms the deletion action)

## 8. UI Color Scheme and Typography

### 8.1 Color Palette
- **Primary Color**: #3498db (Blue)
- **Secondary Color**: #2ecc71 (Green)
- **Accent Color**: #e74c3c (Red)
- **Background**: #f8f9fa (Light Gray)
- **Text**: #333333 (Dark Gray)
- **Borders**: #dee2e6 (Light Gray)
- **Success**: #28a745 (Green)
- **Error**: #dc3545 (Red)
- **Warning**: #ffc107 (Yellow)
- **Info**: #17a2b8 (Cyan)

### 8.2 Typography
- **Primary Font**: 'Roboto', sans-serif
- **Heading Sizes**:
  - H1: 24px
  - H2: 20px
  - H3: 18px
  - H4: 16px
- **Body Text**: 14px
- **Small Text**: 12px
- **Font Weights**:
  - Regular: 400
  - Medium: 500
  - Bold: 700

### 8.3 Button Styles
- **Primary Button**:
  - Background: #3498db
  - Text: White
  - Border: None
  - Border-radius: 4px
  - Padding: 8px 16px
  - Hover: Darken by 10%

- **Secondary Button**:
  - Background: White
  - Text: #3498db
  - Border: 1px solid #3498db
  - Border-radius: 4px
  - Padding: 8px 16px
  - Hover: Light blue background

- **Danger Button**:
  - Background: #e74c3c
  - Text: White
  - Border: None
  - Border-radius: 4px
  - Padding: 8px 16px
  - Hover: Darken by 10%

## 9. Responsive Design Considerations

### 9.1 Mobile View Adjustments
- Navigation collapses into a hamburger menu
- Tables convert to cards for better mobile viewing
- Forms stack vertically with full-width inputs
- Action buttons use icons instead of text where appropriate
- Dashboard widgets stack vertically

### 9.2 Tablet View Adjustments
- Sidebar collapses to icons only
- Book list shows fewer columns
- Quick action buttons remain visible
- Dashboard displays 1-2 widgets per row

### 9.3 Desktop View
- Full navigation bar
- Multi-column layout for forms
- Dashboard displays 2-3 widgets per row
- Tables display all columns
- Action menus fully expanded 