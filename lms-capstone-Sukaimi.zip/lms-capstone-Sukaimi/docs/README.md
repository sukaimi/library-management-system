# Library Management System Documentation

This folder contains all the documentation related to the Library Management System project.

## Documents

### Business Requirements Document (BRD)
- **File:** [library_management_system_brd.md](library_management_system_brd.md)
- **Description:** Outlines the business requirements, features, and specifications of the Library Management System.
- **Content:** Includes system overview, user roles, functional and non-functional requirements, data structures, API endpoints, and more.

### Software Requirements Specification (SRS)
- **File:** [library_management_system_srs.md](library_management_system_srs.md)
- **Description:** Provides detailed technical specifications for the implementation of the Library Management System.
- **Content:** Includes detailed functional and non-functional requirements, system interfaces, data models, API endpoints, and technical constraints.

### Test Cases
- **File:** [library_management_system_test_cases.md](library_management_system_test_cases.md)
- **Description:** Comprehensive test cases for validating the Library Management System functionality.
- **Content:** Includes test scenarios for user authentication, book management, search functionality, borrowing operations, and role-based access control.

### Wireframes
- **File:** [library_management_system_wireframes.md](library_management_system_wireframes.md)
- **Description:** Visual representations of the user interface design for the Library Management System.
- **Content:** Includes mockups of key screens, UI components, color schemes, typography, and responsive design considerations.

## Project Structure

The Library Management System project is organized as follows:

```
lms-capstone/
├── backend/               # Spring Boot backend
│   ├── src/               # Source code
│   │   ├── main/
│   │   │   ├── java/      # Java code
│   │   │   └── resources/ # Configuration files
│   │   └── test/          # Test code
│   └── pom.xml            # Maven dependencies
│
├── frontend/              # React frontend
│   ├── src/               # Source code
│   │   ├── components/    # React components
│   │   ├── App.jsx        # Main application component
│   │   └── main.jsx       # Entry point
│   └── package.json       # npm dependencies
│
└── docs/                  # Documentation
    ├── README.md          # This file
    ├── library_management_system_brd.md  # Business Requirements Document
    ├── library_management_system_srs.md  # Software Requirements Specification
    ├── library_management_system_test_cases.md  # Test Cases
    └── library_management_system_wireframes.md  # Wireframes
```

## Development Environment

### Backend
- Java 17+
- Spring Boot 3.x
- Maven
- MySQL 8.x

### Frontend
- Node.js 18+
- React 19.x
- Bootstrap 5.x
- Vite

## How to Use This Documentation

1. Start with the Business Requirements Document to understand the project's scope and requirements
2. Refer to the Software Requirements Specification for detailed technical specifications
3. Review the Wireframes to understand the UI/UX design
4. Use the Test Cases document for QA and validation activities
5. Use specific sections for information about features, data models, and APIs
6. Use this documentation as a reference during development and testing

## Contributing to Documentation

When adding or updating documentation:

1. Follow the established format and structure
2. Use Markdown for all documentation files
3. Include diagrams or screenshots when helpful
4. Keep documentation up-to-date with code changes 