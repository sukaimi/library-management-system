# Library Management System - User Manual

## Table of Contents
1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [User Roles](#user-roles)
4. [Features](#features)
5. [Troubleshooting](#troubleshooting)

## Introduction
Welcome to the Library Management System! This manual will guide you through using the system effectively. The system is designed to help librarians manage books and members borrow books efficiently.

## Getting Started

### Accessing the System
1. Open your web browser and navigate to the Library Management System URL
2. You will be presented with the login screen
3. Enter your credentials:
   - For Librarians: Use your assigned librarian account
   - For Members: Use your registered member account

### Demo Accounts
For testing purposes, you can use these demo accounts:
- Librarian Accounts:
  - Username: librarian@library.com
  - Password: librarian123
  - Username: aida@gmail.com
  - Password: member123
  - Username: diana.prince@example.com
  - Password: 123
- Member Account:
  - Username: member
  - Password: member123

## User Roles

### Librarian Role
Librarians have full access to the system and can:
- Add new books
- Edit existing book information
- Delete books
- Manage book status (borrowed/available)
- View all books in the library
- Search for books
- Return books on behalf of members
- View active borrowings for each book

### Member Role
Members can:
- View available books
- Search for books
- Borrow available books
- Return borrowed books
- View their borrowed books

## Features

### Book Management
#### Adding a Book (Librarian Only)
1. Click the "Add Book" button
2. Fill in the book details:
   - Title
   - Author
   - ISBN
   - Category
   - Publication Year
   - Status (Available)
3. Click "Save" to add the book

#### Editing a Book (Librarian Only)
1. Find the book you want to edit
2. Click the "Edit" button
3. Modify the book details
4. Click "Save" to update
5. View and manage active borrowings for the book

#### Deleting a Book (Librarian Only)
1. Find the book you want to delete
2. Click the "Delete" button
3. Confirm the deletion in the popup dialog

### Book Catalog
- Books are sorted alphabetically by title
- Display is paginated with 5 books per page
- Navigate through pages using the pagination controls
- View book status and quantity information
- Librarians can toggle book status by clicking on the status badge

### Book Search
1. Use the search bar at the top of the page
2. Enter the book title, author, or ISBN
3. Results will appear automatically as you type
4. Click on a book to view its details

### Borrowing Books
1. Search for the book you want to borrow
2. If the book is available, click the "Borrow" button
3. The book status will update to "Borrowed"
4. The book will be assigned to your account

### Returning Books
1. Find the book you want to return
2. Click the "Return" button
3. The book status will update to "Available"

### Session Management
- Your login session persists across page refreshes
- You will remain logged in until you explicitly log out
- You can access the system from multiple tabs while logged in

## Troubleshooting

### Common Issues
1. **Cannot Log In**
   - Check your username and password
   - Ensure caps lock is off
   - Try clearing your browser cache
   - Make sure you're using the correct email format

2. **Cannot Borrow Book**
   - Verify the book is available
   - Check if you have any overdue books
   - Ensure you're logged in as a member

3. **Search Not Working**
   - Check your internet connection
   - Try refreshing the page
   - Verify the search term is correct

### Need Help?
If you encounter any issues:
1. Check this manual for relevant information
2. Contact your system administrator
3. Report technical issues to the IT department

## Best Practices
1. Always log out when you're done using the system
2. Keep your password secure and change it regularly
3. Report any system issues immediately
4. Follow the library's borrowing policies
5. Keep track of borrowed books and return them on time

## System Requirements
- Modern web browser (Chrome, Firefox, Safari, or Edge)
- Stable internet connection
- JavaScript enabled
- Minimum screen resolution: 1024x768

## Support
For technical support or questions:
- Contact: [Your Library Support Email]
- Phone: [Your Library Support Phone]
- Hours: [Support Hours] 