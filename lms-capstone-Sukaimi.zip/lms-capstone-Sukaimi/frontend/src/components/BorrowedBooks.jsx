import { useState, useEffect, forwardRef } from 'react';
import axios from 'axios';
import { Card, Table, Button, Alert, Spinner } from 'react-bootstrap';

const BorrowedBooks = forwardRef(({ userId, onBookReturned }, ref) => {
  const [borrowings, setBorrowings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchBorrowedBooks = async () => {
    try {
      const response = await axios.get(`http://localhost:8081/api/borrowings/user/${userId}/active`);
      setBorrowings(response.data);
    } catch (err) {
      setError('Failed to fetch borrowed books');
      console.error('Error fetching borrowed books:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBorrowedBooks();
  }, [userId]);

  // Expose fetchBorrowedBooks through ref
  useEffect(() => {
    if (ref) {
      ref.current = {
        fetchBorrowedBooks
      };
    }
  }, [ref]);

  const handleReturn = async (borrowingId) => {
    try {
      await axios.post(`http://localhost:8081/api/borrowings/return/${borrowingId}`);
      // Refresh the list after returning a book
      fetchBorrowedBooks();
      // Notify parent component about the book return
      if (onBookReturned) {
        onBookReturned();
      }
    } catch (err) {
      setError('Failed to return book');
      console.error('Error returning book:', err);
    }
  };

  if (loading) {
    return (
      <div className="text-center p-4">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  if (borrowings.length === 0) {
    return <Alert variant="info">You haven't borrowed any books yet.</Alert>;
  }

  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>Book Title</th>
          <th>Author</th>
          <th>Borrow Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {borrowings.map((borrowing) => (
          <tr key={borrowing.borrowingId}>
            <td>{borrowing.book.title}</td>
            <td>{borrowing.book.author}</td>
            <td>{new Date(borrowing.borrowDate).toLocaleDateString()}</td>
            <td>
              <Button 
                variant="primary" 
                size="sm"
                onClick={() => handleReturn(borrowing.borrowingId)}
              >
                Return Book
              </Button>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
});

export default BorrowedBooks; 