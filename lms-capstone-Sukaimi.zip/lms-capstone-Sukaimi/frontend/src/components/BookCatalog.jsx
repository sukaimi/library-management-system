import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Card, Table, Button, Alert, Spinner, Modal, Pagination } from 'react-bootstrap';
import SearchBar from './SearchBar';
import BorrowedBooks from './BorrowedBooks';

function BookCatalog({ userRole, userId }) {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [alert, setAlert] = useState({ message: '', type: '' });
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedBook, setSelectedBook] = useState(null);
  const [activeBorrowings, setActiveBorrowings] = useState([]);
  const [editFormData, setEditFormData] = useState({
    title: '',
    author: '',
    category: '',
    isbn: '',
    pub_year: '',
    quantity: 0
  });
  const [currentPage, setCurrentPage] = useState(1);
  const booksPerPage = 5;
  const borrowedBooksRef = useRef(null);

  const showAlert = (message, type) => {
    setAlert({ message, type });
    setTimeout(() => setAlert({ message: '', type: '' }), 5000);
  };

  const fetchBooks = async () => {
    try {
      const response = await axios.get('http://localhost:8081/api/books');
      // Sort books by title in ascending order
      const sortedBooks = response.data.sort((a, b) => a.title.localeCompare(b.title));
      setBooks(sortedBooks);
    } catch (err) {
      setError('Failed to fetch books');
      console.error('Error fetching books:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchActiveBorrowings = async (bookId) => {
    try {
      const response = await axios.get(`http://localhost:8081/api/borrowings/book/${bookId}/active`);
      setActiveBorrowings(response.data);
    } catch (err) {
      console.error('Error fetching active borrowings:', err);
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  // Calculate pagination values
  const indexOfLastBook = currentPage * booksPerPage;
  const indexOfFirstBook = indexOfLastBook - booksPerPage;
  const currentBooks = books.slice(indexOfFirstBook, indexOfLastBook);
  const totalPages = Math.ceil(books.length / booksPerPage);

  // Handle page change
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleBorrow = async (bookId) => {
    try {
      await axios.post(`http://localhost:8081/api/borrowings/borrow?userId=${userId}&bookId=${bookId}`);
      showAlert('Book borrowed successfully!', 'success');
      fetchBooks();
      // Refresh borrowed books list
      if (borrowedBooksRef.current) {
        borrowedBooksRef.current.fetchBorrowedBooks();
      }
    } catch (err) {
      showAlert(err.response?.data || 'Failed to borrow book', 'danger');
    }
  };

  const handleBookReturned = () => {
    fetchBooks();
    showAlert('Book returned successfully!', 'success');
  };

  const handleEditBook = async (book) => {
    setSelectedBook(book);
    setEditFormData({
      title: book.title,
      author: book.author,
      category: book.category,
      isbn: book.isbn,
      pub_year: book.pub_year,
      quantity: book.quantity
    });
    await fetchActiveBorrowings(book.bookId);
    setShowEditModal(true);
  };

  const handleDeleteClick = (book) => {
    setSelectedBook(book);
    setShowDeleteModal(true);
  };

  const handleEditSubmit = async () => {
    try {
      await axios.put(`http://localhost:8081/api/books/${selectedBook.bookId}`, editFormData);
      showAlert('Book updated successfully!', 'success');
      setShowEditModal(false);
      fetchBooks();
    } catch (err) {
      showAlert(err.response?.data || 'Failed to update book', 'danger');
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`http://localhost:8081/api/books/${selectedBook.bookId}`);
      showAlert('Book deleted successfully!', 'success');
      setShowDeleteModal(false);
      fetchBooks();
    } catch (err) {
      showAlert(err.response?.data || 'Failed to delete book', 'danger');
    }
  };

  const handleEditChange = (e) => {
    setEditFormData({
      ...editFormData,
      [e.target.name]: e.target.value
    });
  };

  const handleReturnBook = async (borrowingId) => {
    try {
      await axios.post(`http://localhost:8081/api/borrowings/return/${borrowingId}`);
      showAlert('Book returned successfully!', 'success');
      fetchBooks();
      fetchActiveBorrowings(selectedBook.bookId);
    } catch (err) {
      showAlert(err.response?.data || 'Failed to return book', 'danger');
    }
  };

  const handleStatusToggle = async (book) => {
    if (userRole !== 'LIBRARIAN') return;

    try {
      // If setting to AVAILABLE, we need to handle any active borrowings
      if (book.avail === 'BORROWED') {
        // Get active borrowings for this book
        const response = await axios.get(`http://localhost:8081/api/borrowings/book/${book.bookId}/active`);
        const activeBorrowings = response.data;

        // Return all active borrowings
        for (const borrowing of activeBorrowings) {
          await axios.post(`http://localhost:8081/api/borrowings/return/${borrowing.borrowingId}`);
        }
      }

      const updatedBook = {
        ...book,
        avail: book.avail === 'AVAILABLE' ? 'BORROWED' : 'AVAILABLE',
        quantity: book.avail === 'AVAILABLE' ? 0 : 1
      };
      await axios.put(`http://localhost:8081/api/books/${book.bookId}`, updatedBook);
      showAlert(`Book status updated to ${updatedBook.avail}`, 'success');
      fetchBooks();
    } catch (err) {
      showAlert(err.response?.data || 'Failed to update book status', 'danger');
    }
  };

  if (loading) {
    return (
      <div className="text-center p-4">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  return (
    <>
      {alert.message && (
        <Alert variant={alert.type} onClose={() => setAlert({ message: '', type: '' })} dismissible>
          {alert.message}
        </Alert>
      )}

      <SearchBar 
        onStatusChange={fetchBooks} 
        showAlert={showAlert} 
        userRole={userRole}
        userId={userId}
      />

      {userRole === 'MEMBER' && (
        <Card className="mt-4">
          <Card.Header className="bg-primary text-white">
            <h5 className="mb-0">My Borrowed Books</h5>
          </Card.Header>
          <Card.Body>
            <BorrowedBooks 
              ref={borrowedBooksRef}
              userId={userId} 
              onBookReturned={handleBookReturned}
            />
          </Card.Body>
        </Card>
      )}
      
      <Card className="mt-4">
        <Card.Header className="bg-primary text-white d-flex justify-content-between align-items-center">
          <h5 className="mb-0">Book Catalog</h5>
          {userRole === 'LIBRARIAN' && (
            <span className="badge bg-warning text-dark">Librarian View</span>
          )}
        </Card.Header>
        <Card.Body>
          <Table striped hover responsive>
            <thead>
              <tr>
                <th>#</th>
                <th>Title</th>
                <th>Author</th>
                <th>Category</th>
                <th>Year</th>
                <th>ISBN</th>
                <th>Status</th>
                <th>Quantity</th>
                {userRole === 'LIBRARIAN' && <th>Actions</th>}
                {userRole === 'MEMBER' && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {currentBooks.map((book, index) => (
                <tr key={book.bookId}>
                  <td>{indexOfFirstBook + index + 1}</td>
                  <td>{book.title}</td>
                  <td>{book.author}</td>
                  <td>{book.category}</td>
                  <td>{book.pub_year}</td>
                  <td>{book.isbn}</td>
                  <td>
                    <span 
                      className={`badge ${book.avail === 'AVAILABLE' ? 'bg-success' : 'bg-danger'} ${userRole === 'LIBRARIAN' ? 'cursor-pointer' : ''}`}
                      onClick={() => userRole === 'LIBRARIAN' && handleStatusToggle(book)}
                      style={{ cursor: userRole === 'LIBRARIAN' ? 'pointer' : 'default' }}
                    >
                      {book.avail}
                    </span>
                  </td>
                  <td>{book.quantity}</td>
                  {userRole === 'LIBRARIAN' && (
                    <td>
                      <Button
                        variant="outline-primary"
                        size="sm"
                        className="me-1"
                        onClick={() => handleEditBook(book)}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="outline-danger"
                        size="sm"
                        onClick={() => handleDeleteClick(book)}
                      >
                        Delete
                      </Button>
                    </td>
                  )}
                  {userRole === 'MEMBER' && (
                    <td>
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => handleBorrow(book.bookId)}
                        disabled={book.avail !== 'AVAILABLE' || book.quantity <= 0}
                      >
                        Borrow
                      </Button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </Table>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="d-flex justify-content-center mt-4">
              <Pagination>
                <Pagination.First 
                  onClick={() => handlePageChange(1)} 
                  disabled={currentPage === 1}
                />
                <Pagination.Prev 
                  onClick={() => handlePageChange(currentPage - 1)} 
                  disabled={currentPage === 1}
                />
                {[...Array(totalPages)].map((_, index) => (
                  <Pagination.Item
                    key={index + 1}
                    active={index + 1 === currentPage}
                    onClick={() => handlePageChange(index + 1)}
                  >
                    {index + 1}
                  </Pagination.Item>
                ))}
                <Pagination.Next 
                  onClick={() => handlePageChange(currentPage + 1)} 
                  disabled={currentPage === totalPages}
                />
                <Pagination.Last 
                  onClick={() => handlePageChange(totalPages)} 
                  disabled={currentPage === totalPages}
                />
              </Pagination>
            </div>
          )}
        </Card.Body>
      </Card>

      {/* Edit Book Modal */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Edit Book</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form>
            <div className="mb-3">
              <label className="form-label">Title</label>
              <input
                type="text"
                className="form-control"
                name="title"
                value={editFormData.title}
                onChange={handleEditChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Author</label>
              <input
                type="text"
                className="form-control"
                name="author"
                value={editFormData.author}
                onChange={handleEditChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Category</label>
              <input
                type="text"
                className="form-control"
                name="category"
                value={editFormData.category}
                onChange={handleEditChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">ISBN</label>
              <input
                type="text"
                className="form-control"
                name="isbn"
                value={editFormData.isbn}
                onChange={handleEditChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Publication Year</label>
              <input
                type="number"
                className="form-control"
                name="pub_year"
                value={editFormData.pub_year}
                onChange={handleEditChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Quantity</label>
              <input
                type="number"
                className="form-control"
                name="quantity"
                value={editFormData.quantity}
                onChange={handleEditChange}
              />
            </div>
          </form>

          {/* Active Borrowings Section */}
          {userRole === 'LIBRARIAN' && activeBorrowings.length > 0 && (
            <div className="mt-4">
              <h5>Active Borrowings</h5>
              <Table striped bordered hover size="sm">
                <thead>
                  <tr>
                    <th>Borrower</th>
                    <th>Borrow Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {activeBorrowings.map((borrowing) => (
                    <tr key={borrowing.borrowingId}>
                      <td>{borrowing.user.userName}</td>
                      <td>{new Date(borrowing.borrowDate).toLocaleDateString()}</td>
                      <td>
                        <Button
                          variant="success"
                          size="sm"
                          onClick={() => handleReturnBook(borrowing.borrowingId)}
                        >
                          Return
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleEditSubmit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Book Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Delete Book</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete "{selectedBook?.title}"?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default BookCatalog; 