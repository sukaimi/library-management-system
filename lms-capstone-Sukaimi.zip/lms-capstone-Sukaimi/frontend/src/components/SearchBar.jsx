import { useState } from 'react';
import axios from 'axios';
import { Form, Button, Row, Col, Card, ListGroup, Badge, InputGroup } from 'react-bootstrap';
import { Search } from 'react-bootstrap-icons';
import './SearchBar.css';

const SearchBar = ({ onStatusChange, showAlert, userRole, userId }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const isLibrarian = () => userRole === 'LIBRARIAN';

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchTerm.trim()) {
      showAlert('Please enter a search term', 'warning');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.get(`http://localhost:8081/api/books/search?title=${searchTerm}`);
      setSearchResults(response.data);
      if (response.data.length === 0) {
        showAlert('No books found matching your search.', 'info');
      }
    } catch (error) {
      console.error('Error searching books:', error);
      showAlert('Error searching books. Please try again.', 'danger');
    } finally {
      setLoading(false);
    }
  };

  const handleBorrow = async (bookId) => {
    try {
      await axios.post(`http://localhost:8081/api/borrowings/borrow?userId=${userId}&bookId=${bookId}`);
      showAlert('Book borrowed successfully!', 'success');
      // Update the book status in search results
      setSearchResults(prevResults =>
        prevResults.map(book =>
          book.bookId === bookId
            ? { ...book, avail: 'BORROWED' }
            : book
        )
      );
      // Refresh the main book list
      if (onStatusChange) {
        onStatusChange();
      }
    } catch (error) {
      console.error('Error borrowing book:', error);
      showAlert(error.response?.data || 'Failed to borrow book. Please try again.', 'danger');
    }
  };

  const handleReturn = async (bookId) => {
    if (!isLibrarian()) {
      showAlert('Only librarians can return books. Please contact a librarian for assistance.', 'warning');
      return;
    }
    
    try {
      await axios.put(`http://localhost:8081/api/books/${bookId}/return`);
      showAlert('Book returned successfully!', 'success');
      // Update the book status in search results
      setSearchResults(prevResults =>
        prevResults.map(book =>
          book.bookId === bookId
            ? { ...book, avail: 'AVAILABLE' }
            : book
        )
      );
      // Refresh the main book list
      if (onStatusChange) {
        onStatusChange();
      }
    } catch (error) {
      console.error('Error returning book:', error);
      showAlert('Failed to return book. Please try again.', 'danger');
    }
  };

  return (
    <Card className="search-card mb-4">
      <Card.Header className="bg-primary text-white">
        <h5 className="mb-0">Search Books</h5>
      </Card.Header>
      <Card.Body>
        <Form onSubmit={handleSearch}>
          <Row className="mb-3">
            <Col md={10}>
              <InputGroup>
                <InputGroup.Text>
                  <Search />
                </InputGroup.Text>
                <Form.Control
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by title..."
                  aria-label="Search books"
                />
              </InputGroup>
            </Col>
            <Col md={2}>
              <Button 
                variant="primary" 
                type="submit" 
                className="w-100" 
                disabled={loading}
              >
                {loading ? 'Searching...' : 'Search'}
              </Button>
            </Col>
          </Row>
        </Form>

        {searchResults.length > 0 && (
          <div className="mt-4">
            <h6>Search Results ({searchResults.length})</h6>
            <ListGroup>
              {searchResults.map(book => (
                <ListGroup.Item key={book.bookId} className="d-flex justify-content-between align-items-center flex-wrap">
                  <div className="book-details">
                    <h6 className="mb-1">{book.title}</h6>
                    <p className="text-muted mb-1">by {book.author}</p>
                    <div className="d-flex flex-wrap gap-2 small">
                      <Badge bg="secondary">{book.category}</Badge>
                      <Badge bg="info">ISBN: {book.isbn}</Badge>
                      <Badge bg="dark">Year: {book.pub_year}</Badge>
                      <Badge bg={book.avail === 'AVAILABLE' ? 'success' : 'danger'}>
                        {book.avail}
                      </Badge>
                    </div>
                  </div>
                  <div className="mt-2 mt-md-0">
                    {book.avail === 'AVAILABLE' ? (
                      <Button 
                        variant="outline-success" 
                        size="sm"
                        onClick={() => handleBorrow(book.bookId)}
                      >
                        Borrow
                      </Button>
                    ) : (
                      /* Only librarians can return books */
                      isLibrarian() ? (
                        <Button 
                          variant="outline-danger" 
                          size="sm"
                          onClick={() => handleReturn(book.bookId)}
                        >
                          Return
                        </Button>
                      ) : (
                        <Button 
                          variant="outline-secondary" 
                          size="sm"
                          disabled
                          title="Contact a librarian to return this book"
                        >
                          Borrowed
                        </Button>
                      )
                    )}
                  </div>
                </ListGroup.Item>
              ))}
            </ListGroup>
          </div>
        )}
      </Card.Body>
    </Card>
  );
};

export default SearchBar; 