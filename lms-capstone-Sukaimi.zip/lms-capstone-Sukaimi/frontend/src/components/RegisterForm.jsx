import { useState } from 'react';
import axios from 'axios';
import { Form, Button, Card, Row, Col, InputGroup } from 'react-bootstrap';
import { PersonFill, EnvelopeFill, KeyFill } from 'react-bootstrap-icons';
import './RegisterForm.css';

function RegisterForm({ showAlert }) {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: ''
  });
  const [validated, setValidated] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const form = e.currentTarget;
    if (form.checkValidity() === false) {
      e.stopPropagation();
      setValidated(true);
      return;
    }
    
    setValidated(true);

    try {
      await axios.post('http://localhost:8081/api/users/register', formData);
      showAlert('Registration successful!', 'success');
      setFormData({ username: '', email: '', password: '' });
      setValidated(false);
    } catch (error) {
      const errorMessage = error.response?.data || 'Registration failed. Please try again.';
      showAlert(errorMessage, 'danger');
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <Card className="register-card">
      <Card.Header className="bg-primary text-white">
        <h5 className="mb-0">Register</h5>
      </Card.Header>
      <Card.Body>
        <Form noValidate validated={validated} onSubmit={handleSubmit}>
          <Row className="mb-3">
            <Col>
              <Form.Group controlId="username">
                <Form.Label>Username</Form.Label>
                <InputGroup hasValidation>
                  <InputGroup.Text>
                    <PersonFill />
                  </InputGroup.Text>
                  <Form.Control
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    placeholder="Enter username"
                    required
                  />
                  <Form.Control.Feedback type="invalid">
                    Username is required
                  </Form.Control.Feedback>
                </InputGroup>
              </Form.Group>
            </Col>
          </Row>

          <Row className="mb-3">
            <Col>
              <Form.Group controlId="email">
                <Form.Label>Email</Form.Label>
                <InputGroup hasValidation>
                  <InputGroup.Text>
                    <EnvelopeFill />
                  </InputGroup.Text>
                  <Form.Control
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Enter email"
                    required
                    pattern="\S+@\S+\.\S+"
                  />
                  <Form.Control.Feedback type="invalid">
                    Please enter a valid email address
                  </Form.Control.Feedback>
                </InputGroup>
              </Form.Group>
            </Col>
          </Row>

          <Row className="mb-4">
            <Col>
              <Form.Group controlId="password">
                <Form.Label>Password</Form.Label>
                <InputGroup hasValidation>
                  <InputGroup.Text>
                    <KeyFill />
                  </InputGroup.Text>
                  <Form.Control
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Enter password"
                    required
                    minLength="6"
                  />
                  <Form.Control.Feedback type="invalid">
                    Password must be at least 6 characters
                  </Form.Control.Feedback>
                </InputGroup>
              </Form.Group>
            </Col>
          </Row>

          <div className="d-grid mb-3">
            <Button variant="primary" type="submit">
              Register
            </Button>
          </div>
          
          <div className="text-center">
            <small className="text-muted">
              Already have an account? <a href="#login" className="text-decoration-none">Login here</a>
            </small>
          </div>
        </Form>
      </Card.Body>
    </Card>
  );
}

export default RegisterForm; 