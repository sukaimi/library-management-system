import { useState, useEffect } from 'react';
import axios from 'axios';
import { Form, Button, Card, Row, Col, InputGroup, Alert } from 'react-bootstrap';
import { EnvelopeFill, KeyFill } from 'react-bootstrap-icons';
import './LoginForm.css';

function LoginForm({ showAlert, onLogin }) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [validated, setValidated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginMessage, setLoginMessage] = useState({ text: '', type: '' });

  // Check for existing login data when component mounts
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      if (onLogin) {
        onLogin(userData);
      }
    }
  }, [onLogin]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const form = e.currentTarget;
    if (form.checkValidity() === false) {
      e.stopPropagation();
      setValidated(true);
      return;
    }
    
    setValidated(true);
    setLoading(true);
    setLoginMessage({ text: '', type: '' });

    try {
      const response = await axios.post('http://localhost:8081/api/users/login', formData);
      const userData = {
        username: response.data.username,
        email: response.data.email,
        id: response.data.userId,
        role: response.data.userRole
      };
      
      setLoginMessage({ text: 'Login successful!', type: 'success' });
      
      // Call the onLogin function passed from parent component
      if (onLogin) {
        onLogin(userData);
      }
    } catch (error) {
      console.error('Login error:', error);
      setLoginMessage({ 
        text: error.response?.data || 'Login failed. Please try again.', 
        type: 'danger' 
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <Card className="login-card">
      <Card.Header className="bg-primary text-white">
        <h5 className="mb-0">Login to Library System</h5>
      </Card.Header>
      <Card.Body>
        {loginMessage.text && (
          <Alert variant={loginMessage.type} className="mb-3">
            {loginMessage.text}
          </Alert>
        )}
        
        <Form noValidate validated={validated} onSubmit={handleSubmit}>
          <Row className="mb-3">
            <Col>
              <Form.Group controlId="email">
                <Form.Label>Email</Form.Label>
                <InputGroup hasValidation>
                  <InputGroup.Text>
                    <EnvelopeFill />
                  </InputGroup.Text>
                  <Form.Control
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Enter email"
                    required
                    pattern="\S+@\S+\.\S+"
                  />
                  <Form.Control.Feedback type="invalid">
                    Please enter a valid email address
                  </Form.Control.Feedback>
                </InputGroup>
              </Form.Group>
            </Col>
          </Row>

          <Row className="mb-4">
            <Col>
              <Form.Group controlId="password">
                <Form.Label>Password</Form.Label>
                <InputGroup hasValidation>
                  <InputGroup.Text>
                    <KeyFill />
                  </InputGroup.Text>
                  <Form.Control
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Enter password"
                    required
                  />
                  <Form.Control.Feedback type="invalid">
                    Password is required
                  </Form.Control.Feedback>
                </InputGroup>
              </Form.Group>
            </Col>
          </Row>

          <div className="d-flex flex-column gap-2">
            <Button 
              variant="primary" 
              type="submit" 
              className="w-100"
              disabled={loading}
            >
              {loading ? 'Logging in...' : 'Login'}
            </Button>
            
            <div className="text-center mt-3">
              <small className="text-muted">
                Don't have an account? <a href="#register" className="text-decoration-none">Register here</a>
              </small>
            </div>
          </div>
        </Form>
      </Card.Body>
    </Card>
  );
}

export default LoginForm; 