import './App.css'
import { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Navbar, Nav, Form, Button, Card, Alert, Badge, Modal } from 'react-bootstrap';
import RegisterForm from './components/RegisterForm';
import LoginForm from './components/LoginForm';
import BookCatalog from './components/BookCatalog';
import './components/RegisterForm.css';
import './components/LoginForm.css';

function App() {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [category, setCategory] = useState('');
  const [pub_year, setPub_year] = useState('');
  const [isbn, setIsbn] = useState('');
  const [activeTab, setActiveTab] = useState('login');
  const [alertMessage, setAlertMessage] = useState('');
  const [alertVariant, setAlertVariant] = useState('success');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  
  // Edit book state
  const [editMode, setEditMode] = useState(false);
  const [currentBook, setCurrentBook] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  
  // Delete confirmation modal
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [bookToDelete, setBookToDelete] = useState(null);

  // Check for existing login data when component mounts
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      setUser(userData);
      setIsAuthenticated(true);
      setActiveTab('catalog');
    }
  }, []);

  // Handle successful login
  const handleLogin = (userData) => {
    setUser(userData);
    setIsAuthenticated(true);
    setActiveTab('catalog');
    // Store user data in localStorage
    localStorage.setItem('user', JSON.stringify(userData));
    showAlert(`Welcome, ${userData.username}! You are logged in as ${userData.role}.`, 'success');
  };

  // Handle logout
  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setActiveTab('login');
    // Remove user data from localStorage
    localStorage.removeItem('user');
    showAlert('You have been logged out successfully.', 'info');
  };

  // Check if user is librarian
  const isLibrarian = () => {
    return user && user.role === 'LIBRARIAN';
  };

  // Add a new book
  const handleAddBook = (e) => {
    e.preventDefault();
    
    // Basic validation
    if (!title || !author || !category || !pub_year || !isbn) {
      showAlert('All fields are required!', 'danger');
      return;
    }

    const year = parseInt(pub_year);
    if (year < 1500) {
      showAlert('Publication year must be 1500 or later!', 'danger');
      return;
    }

    const newBook = { 
      title, 
      author, 
      category, 
      pub_year: year, 
      isbn,
      avail: 'AVAILABLE',
      quantity: 1 // Add default quantity
    };

    console.log('Sending book data:', newBook);
    
    axios.post('http://localhost:8081/api/books', newBook)
      .then(response => {
        console.log('Book added successfully:', response.data);
        // Clear all form fields
        setTitle('');
        setAuthor('');
        setCategory('');
        setPub_year('');
        setIsbn('');
        showAlert('Book added successfully!', 'success');
      })
      .catch(error => {
        console.error('Error adding book:', error);
        if (error.response) {
          console.error('Response data:', error.response.data);
          console.error('Response status:', error.response.status);
        }
        showAlert('Failed to add book. Please try again.', 'danger');
      });
  };

  // Open edit modal
  const handleEditBook = (book) => {
    setCurrentBook(book);
    setTitle(book.title);
    setAuthor(book.author);
    setCategory(book.category);
    setPub_year(book.pub_year);
    setIsbn(book.isbn);
    setShowEditModal(true);
  };

  // Save book changes
  const handleSaveBook = () => {
    // Basic validation
    if (!title || !author || !category || !pub_year || !isbn) {
      showAlert('All fields are required!', 'danger');
      return;
    }

    const year = parseInt(pub_year);
    if (year < 1500) {
      showAlert('Publication year must be 1500 or later!', 'danger');
      return;
    }

    const updatedBook = {
      ...currentBook,
      title,
      author,
      category,
      pub_year: year,
      isbn
    };

    axios.put(`http://localhost:8081/api/books/${currentBook.bookId}`, updatedBook)
      .then(response => {
        setShowEditModal(false);
        clearBookForm();
        showAlert('Book updated successfully!', 'success');
      })
      .catch(error => {
        console.error('Error updating book:', error);
        showAlert('Failed to update book. Please try again.', 'danger');
      });
  };

  // Open delete confirmation
  const handleDeleteClick = (book) => {
    setBookToDelete(book);
    setShowDeleteModal(true);
  };

  // Delete the book
  const handleDeleteBook = () => {
    if (!bookToDelete) return;

    axios.delete(`http://localhost:8081/api/books/${bookToDelete.bookId}`)
      .then(() => {
        setShowDeleteModal(false);
        setBookToDelete(null);
        showAlert('Book deleted successfully!', 'success');
      })
      .catch(error => {
        console.error('Error deleting book:', error);
        showAlert('Failed to delete book. Please try again.', 'danger');
      });
  };

  // Clear book form
  const clearBookForm = () => {
    setTitle('');
    setAuthor('');
    setCategory('');
    setPub_year('');
    setIsbn('');
    setCurrentBook(null);
  };

  const showAlert = (message, variant) => {
    setAlertMessage(message);
    setAlertVariant(variant);
    setTimeout(() => {
      setAlertMessage('');
    }, 5000);
  };

  const renderTabContent = () => {
    // If not authenticated, only show login or register
    if (!isAuthenticated && activeTab !== 'register') {
      return <LoginForm showAlert={showAlert} onLogin={handleLogin} />;
    }
    
    if (!isAuthenticated && activeTab === 'register') {
      return <RegisterForm showAlert={showAlert} />;
    }

    // If authenticated, show requested content
    switch(activeTab) {
      case 'catalog':
        return (
          <BookCatalog 
            userRole={user?.role}
            userId={user?.id}
          />
        );
      case 'addBook':
        return (
          <Card className="mt-4">
            <Card.Header className="bg-primary text-white d-flex justify-content-between align-items-center">
              <h5 className="mb-0">Add New Book</h5>
              <Badge bg="warning" text="dark">Librarian Only</Badge>
            </Card.Header>
            <Card.Body>
              <Form onSubmit={handleAddBook}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Title</Form.Label>
                      <Form.Control 
                        type="text" 
                        value={title} 
                        onChange={(e) => setTitle(e.target.value)} 
                        placeholder="Enter book title" 
                        required 
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Author</Form.Label>
                      <Form.Control 
                        type="text" 
                        value={author} 
                        onChange={(e) => setAuthor(e.target.value)} 
                        placeholder="Enter author name" 
                        required 
                      />
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Category</Form.Label>
                      <Form.Control 
                        type="text" 
                        value={category} 
                        onChange={(e) => setCategory(e.target.value)} 
                        placeholder="Enter category" 
                        required 
                      />
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Publication Year</Form.Label>
                      <Form.Control 
                        type="number" 
                        value={pub_year} 
                        onChange={(e) => setPub_year(e.target.value)} 
                        placeholder="1500 or later" 
                        min="1500" 
                        required 
                      />
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>ISBN</Form.Label>
                      <Form.Control 
                        type="text" 
                        value={isbn} 
                        onChange={(e) => setIsbn(e.target.value)} 
                        placeholder="Enter ISBN" 
                        required 
                      />
                    </Form.Group>
                  </Col>
                </Row>
                <Button variant="primary" type="submit">
                  Add Book
                </Button>
              </Form>
            </Card.Body>
          </Card>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <Navbar bg="dark" variant="dark" expand="lg" className="mb-4">
        <Container>
          <Navbar.Brand href="#home">Library Management System</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            {isAuthenticated ? (
              <>
                <Nav className="me-auto">
                  <Nav.Link 
                    href="#catalog" 
                    active={activeTab === 'catalog'} 
                    onClick={() => setActiveTab('catalog')}
                  >
                    Book Catalog
                  </Nav.Link>
                  {isLibrarian() && (
                    <Nav.Link 
                      href="#addBook" 
                      active={activeTab === 'addBook'} 
                      onClick={() => setActiveTab('addBook')}
                    >
                      Add Book
                    </Nav.Link>
                  )}
                </Nav>
                <Nav>
                  <span className="navbar-text me-3 text-light">
                    Welcome, {user?.username}
                    {user?.role && (
                      <Badge bg={user.role === 'LIBRARIAN' ? 'warning' : 'info'} 
                        text={user.role === 'LIBRARIAN' ? 'dark' : 'white'} 
                        className="ms-2"
                      >
                        {user.role}
                      </Badge>
                    )}
                  </span>
                  <Button 
                    variant="outline-light" 
                    size="sm"
                    onClick={handleLogout}
                  >
                    Logout
                  </Button>
                </Nav>
              </>
            ) : (
              <Nav className="ms-auto">
                <Nav.Link 
                  href="#login" 
                  active={activeTab === 'login'} 
                  onClick={() => setActiveTab('login')}
                  className="me-2"
                >
                  Login
                </Nav.Link>
                <Nav.Link 
                  href="#register" 
                  active={activeTab === 'register'} 
                  onClick={() => setActiveTab('register')}
                >
                  Register
                </Nav.Link>
              </Nav>
            )}
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <Container>
        {alertMessage && (
          <Alert variant={alertVariant} onClose={() => setAlertMessage('')} dismissible>
            {alertMessage}
          </Alert>
        )}
        
        {renderTabContent()}
      </Container>

      {/* Edit Book Modal */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Book</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Author</Form.Label>
              <Form.Control
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Category</Form.Label>
              <Form.Control
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Publication Year</Form.Label>
              <Form.Control
                type="number"
                value={pub_year}
                onChange={(e) => setPub_year(e.target.value)}
                min="1500"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>ISBN</Form.Label>
              <Form.Control
                type="text"
                value={isbn}
                onChange={(e) => setIsbn(e.target.value)}
                required
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSaveBook}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete the book "{bookToDelete?.title}"? This action cannot be undone.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteBook}>
            Delete Book
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default App;
