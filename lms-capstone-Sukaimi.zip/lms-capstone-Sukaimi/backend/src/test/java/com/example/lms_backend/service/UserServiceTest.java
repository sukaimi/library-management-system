package com.example.lms_backend.service;

import com.example.lms_backend.model.User;
import com.example.lms_backend.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private User activeUser;
    private User inactiveUser;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Create test users
        activeUser = new User();
        activeUser.setUserId(1L);
        activeUser.setUsername("testuser");
        activeUser.setEmail("test@example.com");
        activeUser.setPassword("password123");
        activeUser.setUserRole(User.Role.MEMBER);
        activeUser.setUserStatus(User.Status.ACTIVE);

        inactiveUser = new User();
        inactiveUser.setUserId(2L);
        inactiveUser.setUsername("inactiveuser");
        inactiveUser.setEmail("inactive@example.com");
        inactiveUser.setPassword("password123");
        inactiveUser.setUserRole(User.Role.MEMBER);
        inactiveUser.setUserStatus(User.Status.INACTIVE);
    }

    @Test
    @DisplayName("Should successfully login with valid credentials")
    void testSuccessfulLogin() {
        // Arrange
        List<User> users = Arrays.asList(activeUser);
        when(userRepository.findAll()).thenReturn(users);

        // Act
        User result = userService.login("test@example.com", "password123");

        // Assert
        assertNotNull(result);
        assertEquals(activeUser.getUserId(), result.getUserId());
        assertEquals(activeUser.getEmail(), result.getEmail());
        assertEquals(activeUser.getUserStatus(), result.getUserStatus());
    }

    @Test
    @DisplayName("Should throw exception for invalid email")
    void testLoginWithInvalidEmail() {
        // Arrange
        List<User> users = Arrays.asList(activeUser);
        when(userRepository.findAll()).thenReturn(users);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            userService.login("wrong@example.com", "password123");
        });
    }

    @Test
    @DisplayName("Should throw exception for invalid password")
    void testLoginWithInvalidPassword() {
        // Arrange
        List<User> users = Arrays.asList(activeUser);
        when(userRepository.findAll()).thenReturn(users);

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            userService.login("test@example.com", "wrongpassword");
        });
    }

    @Test
    @DisplayName("Should throw exception for inactive account")
    void testLoginWithInactiveAccount() {
        // Arrange
        List<User> users = Arrays.asList(inactiveUser);
        when(userRepository.findAll()).thenReturn(users);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.login("inactive@example.com", "password123");
        });
        assertEquals("Account is inactive", exception.getMessage());
    }
} 