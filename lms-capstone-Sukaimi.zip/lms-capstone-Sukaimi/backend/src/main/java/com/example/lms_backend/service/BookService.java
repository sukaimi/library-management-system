package com.example.lms_backend.service;

import com.example.lms_backend.model.Book;
import com.example.lms_backend.model.BookAvail;
import com.example.lms_backend.repository.BookRepository;
import com.example.lms_backend.exception.BookNotFoundException;
import com.example.lms_backend.exception.InvalidBookDataException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;

    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public List<Book> searchBooksByTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new InvalidBookDataException("Search title cannot be empty");
        }
        return bookRepository.findByTitleContainingIgnoreCase(title.trim());
    }

    public Book getBookById(Long id) {
        return bookRepository.findById(id)
            .orElseThrow(() -> new BookNotFoundException("Book not found with id: " + id));
    }

    @Transactional
    public Book createBook(Book book) {
        validateBook(book);
        
        // Check for duplicate ISBN
        if (bookRepository.findByIsbn(book.getIsbn()).isPresent()) {
            throw new InvalidBookDataException("A book with ISBN " + book.getIsbn() + " already exists");
        }

        // Set initial availability status based on quantity
        updateBookAvailability(book);
        
        return bookRepository.save(book);
    }

    @Transactional
    public ResponseEntity<Book> updateBook(Long id, Book bookDetails) {
        Book book = getBookById(id);
        
        // Validate the update data
        validateBook(bookDetails);
        
        // Check for duplicate ISBN if it's being changed
        if (!book.getIsbn().equals(bookDetails.getIsbn())) {
            if (bookRepository.findByIsbn(bookDetails.getIsbn()).isPresent()) {
                throw new InvalidBookDataException("A book with ISBN " + bookDetails.getIsbn() + " already exists");
            }
        }

        book.setTitle(bookDetails.getTitle());
        book.setAuthor(bookDetails.getAuthor());
        book.setCategory(bookDetails.getCategory());
        book.setIsbn(bookDetails.getIsbn());
        book.setPub_year(bookDetails.getPub_year());
        book.setQuantity(bookDetails.getQuantity());
        
        // Update availability status based on new quantity
        updateBookAvailability(book);

        return ResponseEntity.ok(bookRepository.save(book));
    }

    @Transactional
    public ResponseEntity<Void> deleteBook(Long id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            throw new BookNotFoundException("Book not found with id: " + id);
        }
    }

    private void validateBook(Book book) {
        if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
            throw new InvalidBookDataException("Title cannot be empty");
        }
        if (book.getAuthor() == null || book.getAuthor().trim().isEmpty()) {
            throw new InvalidBookDataException("Author cannot be empty");
        }
        if (book.getCategory() == null || book.getCategory().trim().isEmpty()) {
            throw new InvalidBookDataException("Category cannot be empty");
        }
        if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
            throw new InvalidBookDataException("ISBN cannot be empty");
        }
        if (book.getPub_year() < 1500) {
            throw new InvalidBookDataException("Publication year must be 1500 or later");
        }
        if (book.getQuantity() == null || book.getQuantity() < 0) {
            throw new InvalidBookDataException("Book quantity must be non-negative");
        }
    }

    private void updateBookAvailability(Book book) {
        if (book.getQuantity() <= 0) {
            book.setAvail(BookAvail.BORROWED);
        } else {
            book.setAvail(BookAvail.AVAILABLE);
        }
    }

    public Book saveBook(Book book) {
        // Update availability status before saving
        updateBookAvailability(book);
        return bookRepository.save(book);
    }
}