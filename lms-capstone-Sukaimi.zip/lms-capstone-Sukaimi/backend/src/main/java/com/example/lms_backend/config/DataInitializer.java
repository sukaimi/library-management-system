package com.example.lms_backend.config;

import com.example.lms_backend.model.User;
import com.example.lms_backend.model.Book;
import com.example.lms_backend.model.BookAvail;
import com.example.lms_backend.repository.UserRepository;
import com.example.lms_backend.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookRepository bookRepository;

    @Override
    public void run(String... args) {
        // Create demo librarian account if it doesn't exist
        if (!userRepository.existsByUsername("librarian")) {
            User librarian = new User();
            librarian.setUsername("librarian");
            librarian.setEmail("librarian@library.com");
            librarian.setPassword("librarian123");
            librarian.setUserRole(User.Role.LIBRARIAN);
            librarian.setUserStatus(User.Status.ACTIVE);
            userRepository.save(librarian);
        }

        // Create demo member account if it doesn't exist
        if (!userRepository.existsByUsername("member")) {
            User member = new User();
            member.setUsername("member");
            member.setEmail("member@library.com");
            member.setPassword("member123");
            member.setUserRole(User.Role.MEMBER);
            member.setUserStatus(User.Status.ACTIVE);
            userRepository.save(member);
        }

        // Initialize sample books if no books exist
        if (bookRepository.count() == 0) {
            // Sample Book 1
            Book book1 = new Book();
            book1.setTitle("The Great Gatsby");
            book1.setAuthor("F. Scott Fitzgerald");
            book1.setCategory("Fiction");
            book1.setIsbn("978-0743273565");
            book1.setQuantity(5);
            book1.setPub_year(1925);
            book1.setAvail(BookAvail.AVAILABLE);
            bookRepository.save(book1);

            // Sample Book 2
            Book book2 = new Book();
            book2.setTitle("To Kill a Mockingbird");
            book2.setAuthor("Harper Lee");
            book2.setCategory("Fiction");
            book2.setIsbn("978-0446310789");
            book2.setQuantity(3);
            book2.setPub_year(1960);
            book2.setAvail(BookAvail.AVAILABLE);
            bookRepository.save(book2);

            // Sample Book 3
            Book book3 = new Book();
            book3.setTitle("1984");
            book3.setAuthor("George Orwell");
            book3.setCategory("Science Fiction");
            book3.setIsbn("978-0451524935");
            book3.setQuantity(4);
            book3.setPub_year(1949);
            book3.setAvail(BookAvail.AVAILABLE);
            bookRepository.save(book3);
        }
    }
} 