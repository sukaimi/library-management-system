package com.example.lms_backend.repository;

import com.example.lms_backend.model.BookBorrowing;
import com.example.lms_backend.model.User;
import com.example.lms_backend.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookBorrowingRepository extends JpaRepository<BookBorrowing, Long> {
    List<BookBorrowing> findByUser(User user);
    List<BookBorrowing> findByUserAndStatus(User user, BookBorrowing.Status status);
    List<BookBorrowing> findByBookAndStatus(Book book, BookBorrowing.Status status);
} 