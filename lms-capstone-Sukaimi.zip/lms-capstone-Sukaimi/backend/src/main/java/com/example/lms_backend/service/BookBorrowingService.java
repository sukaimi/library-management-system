package com.example.lms_backend.service;

import com.example.lms_backend.model.Book;
import com.example.lms_backend.model.BookBorrowing;
import com.example.lms_backend.model.User;
import com.example.lms_backend.model.BookAvail;
import com.example.lms_backend.repository.BookBorrowingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookBorrowingService {
    private final BookBorrowingRepository bookBorrowingRepository;
    private final UserService userService;
    private final BookService bookService;

    @Autowired
    public BookBorrowingService(BookBorrowingRepository bookBorrowingRepository,
                              UserService userService,
                              BookService bookService) {
        this.bookBorrowingRepository = bookBorrowingRepository;
        this.userService = userService;
        this.bookService = bookService;
    }

    @Transactional
    public BookBorrowing borrowBook(Long userId, Long bookId) {
        User user = userService.getUserById(userId);
        Book book = bookService.getBookById(bookId);

        if (book.getQuantity() <= 0) {
            throw new RuntimeException("Book is not available for borrowing");
        }

        BookBorrowing borrowing = new BookBorrowing();
        borrowing.setUser(user);
        borrowing.setBook(book);
        borrowing.setBorrowDate(LocalDateTime.now());
        borrowing.setStatus(BookBorrowing.Status.BORROWED);

        // Update book quantity and availability status
        book.setQuantity(book.getQuantity() - 1);
        if (book.getQuantity() == 0) {
            book.setAvail(BookAvail.BORROWED);
        }
        bookService.saveBook(book);

        return bookBorrowingRepository.save(borrowing);
    }

    @Transactional
    public BookBorrowing returnBook(Long borrowingId) {
        BookBorrowing borrowing = bookBorrowingRepository.findById(borrowingId)
            .orElseThrow(() -> new RuntimeException("Borrowing record not found"));

        if (borrowing.getStatus() == BookBorrowing.Status.RETURNED) {
            throw new RuntimeException("Book has already been returned");
        }

        borrowing.setReturnDate(LocalDateTime.now());
        borrowing.setStatus(BookBorrowing.Status.RETURNED);

        // Update book quantity and availability status
        Book book = borrowing.getBook();
        book.setQuantity(book.getQuantity() + 1);
        book.setAvail(BookAvail.AVAILABLE);
        bookService.saveBook(book);

        return bookBorrowingRepository.save(borrowing);
    }

    public List<BookBorrowing> getUserBorrowings(Long userId) {
        User user = userService.getUserById(userId);
        return bookBorrowingRepository.findByUser(user);
    }

    public List<BookBorrowing> getUserActiveBorrowings(Long userId) {
        User user = userService.getUserById(userId);
        return bookBorrowingRepository.findByUserAndStatus(user, BookBorrowing.Status.BORROWED);
    }

    public List<BookBorrowing> getBookActiveBorrowings(Long bookId) {
        Book book = bookService.getBookById(bookId);
        return bookBorrowingRepository.findByBookAndStatus(book, BookBorrowing.Status.BORROWED);
    }
} 