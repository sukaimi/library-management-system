package com.example.lms_backend.repository;

import com.example.lms_backend.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    // Finds the highest book_id or returns 49999 if no books exist
    // @Query("SELECT COALESCE(MAX(b.bookId), 49999) FROM Book b")
    //Long getMaxBookId();

    List<Book> findByTitleContainingIgnoreCase(String title);
    Optional<Book> findByIsbn(String isbn);
}