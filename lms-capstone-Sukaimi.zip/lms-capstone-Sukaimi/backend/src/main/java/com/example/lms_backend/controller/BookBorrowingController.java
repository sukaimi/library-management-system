package com.example.lms_backend.controller;

import com.example.lms_backend.model.BookBorrowing;
import com.example.lms_backend.service.BookBorrowingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/borrowings")
@CrossOrigin(origins = "http://localhost:5173")
public class BookBorrowingController {
    private final BookBorrowingService bookBorrowingService;

    @Autowired
    public BookBorrowingController(BookBorrowingService bookBorrowingService) {
        this.bookBorrowingService = bookBorrowingService;
    }

    @PostMapping("/borrow")
    public ResponseEntity<?> borrowBook(@RequestParam Long userId, @RequestParam Long bookId) {
        try {
            BookBorrowing borrowing = bookBorrowingService.borrowBook(userId, bookId);
            return ResponseEntity.ok(borrowing);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/return/{borrowingId}")
    public ResponseEntity<?> returnBook(@PathVariable Long borrowingId) {
        try {
            BookBorrowing borrowing = bookBorrowingService.returnBook(borrowingId);
            return ResponseEntity.ok(borrowing);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookBorrowing>> getUserBorrowings(@PathVariable Long userId) {
        List<BookBorrowing> borrowings = bookBorrowingService.getUserBorrowings(userId);
        return ResponseEntity.ok(borrowings);
    }

    @GetMapping("/user/{userId}/active")
    public ResponseEntity<List<BookBorrowing>> getUserActiveBorrowings(@PathVariable Long userId) {
        List<BookBorrowing> borrowings = bookBorrowingService.getUserActiveBorrowings(userId);
        return ResponseEntity.ok(borrowings);
    }

    @GetMapping("/book/{bookId}/active")
    public ResponseEntity<List<BookBorrowing>> getBookActiveBorrowings(@PathVariable Long bookId) {
        List<BookBorrowing> borrowings = bookBorrowingService.getBookActiveBorrowings(bookId);
        return ResponseEntity.ok(borrowings);
    }
} 