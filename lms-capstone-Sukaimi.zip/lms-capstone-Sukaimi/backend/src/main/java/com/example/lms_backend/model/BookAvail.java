package com.example.lms_backend.model;

/**
 * Enum for Book status
 */
public enum BookAvail {
    AVAILABLE,
    BORROWED,
    RESERVED
}