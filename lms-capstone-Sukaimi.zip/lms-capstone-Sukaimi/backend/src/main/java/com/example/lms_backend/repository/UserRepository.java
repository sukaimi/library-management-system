package com.example.lms_backend.repository;

import com.example.lms_backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Finds the highest user_id or returns 89999 if no users exist
    // @Query("SELECT COALESCE(MAX(u.userId), 89999) FROM User u")
    // Long getMaxUserId();

    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}