package com.example.lms_backend.exception;

public class BookStatusException extends RuntimeException {
    public BookStatusException(String message) {
        super(message);
    }
} 