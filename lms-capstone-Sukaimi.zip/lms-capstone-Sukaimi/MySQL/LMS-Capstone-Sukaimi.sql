create database lms_db;

use lms_db;

CREATE TABLE tbl_books (
    book_id INT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    pub_year INT CHECK (pub_year >= 1500),
    isbn VARCHAR(20) UNIQUE NOT NULL,
    avail ENUM('AVAILABLE', 'BORROWED', 'RESERVED') DEFAULT 'AVAILABLE',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tbl_books (book_id, title, author, category, pub_year, isbn, avail) VALUES
(1, 'Onyx Storm', 'Rebecca Yarros', 'Fantasy', 2025, '9781649374164', 'AVAILABLE'),
(2, 'The Celestial Tides', 'Brandon Sanderson', 'Science Fiction', 2023, '9780765326355', 'AVAILABLE'),
(3, 'Echoes of the Past', 'Colleen Hoover', 'Romance', 2024, '9781501171369', 'BORROWED'),
(4, 'The Forgotten Realm', 'Neil Gaiman', 'Fantasy', 2022, '9780060557812', 'AVAILABLE'),
(5, 'Quantum Paradox', 'Andy Weir', 'Science Fiction', 2025, '9780593355260', 'AVAILABLE');

CREATE TABLE tbl_user (
    user_id INT PRIMARY KEY,
    user_name VARCHAR(100) NOT NULL,
    user_email VARCHAR(100) UNIQUE NOT NULL,
    user_password VARCHAR(255) NOT NULL,
    user_role ENUM('LIBRARIAN', 'MEMBER') NOT NULL,
    user_status ENUM('ACTIVE', 'INACTIVE') DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tbl_user (user_id, user_name, user_email, user_password, user_role, user_status) VALUES
(1, 'Aida Ghani', 'aida.ghanin@gmail.com', '123', 'LIBRARIAN', 'ACTIVE'),
(2, 'Sukaimi Sukri', 'sukaimi@gmail.com', '123', 'MEMBER', 'ACTIVE'),
(3, 'Charlie Brown', 'charlie.brown@example.com', '123', 'MEMBER', 'INACTIVE'),
(4, 'Diana Prince', 'diana.prince@example.com', '123', 'LIBRARIAN', 'ACTIVE'),
(5, 'Ethan Hunt', 'ethan.hunt@example.com', '123', 'MEMBER', 'ACTIVE');
